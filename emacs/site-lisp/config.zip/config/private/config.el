;; -*- lexical-binding: t; -*-

;; Put machine-local settings and secrets here.
;;; ============================================================
;;; LSP Bridge Configuration
;;; ============================================================

;; Enable inlay hints
(setq mcg-lsp-enable-inlay-hint t)

;;; ============================================================
;;; Local Secrets
;;; ============================================================

;; Keep real passwords, tokens, and machine-specific connection details in
;; local-secrets.el. That file is intentionally ignored by git.
(defvar mcg-private-local-secrets-file
  (or (let ((generated-file (and (boundp 'mcg-private-dir)
                                 (expand-file-name "local-secrets.el"
                                                   mcg-private-dir))))
        (and generated-file (file-exists-p generated-file) generated-file))
      (let ((source-file (and (boundp 'mcg-emacs-dir)
                              (expand-file-name
                               "config-org/private/local-secrets.el"
                               mcg-emacs-dir))))
        (and source-file (file-exists-p source-file) source-file))
      (let ((same-dir-file
             (expand-file-name "local-secrets.el"
                               (file-name-directory
                                (or load-file-name buffer-file-name)))))
        (and (file-exists-p same-dir-file) same-dir-file)))
  "Local secrets file loaded by private config when present.")

(when mcg-private-local-secrets-file
  (load mcg-private-local-secrets-file nil t))

;;; ============================================================
;;; Org Configuration
;;; ============================================================

(setq mcg-lsp-enable-inlay-hint t)

(mcg-org-set-storage-root "D:/workspaces/org")

(setq mcg-blog-base-directory "D:/workspaces/blog/mcge-blog")
(setq mcg-org-hugo-postdir "config-org")
(setq mcg-org-blog-capture-directory nil)

(provide 'private-config)
;;; config.el ends here
