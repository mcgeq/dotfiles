;;; config-example.el --- Example private configuration -*- lexical-binding: t; -*-

;;; ============================================================
;;; Startup Configuration
;;; ============================================================

;; Initial frame colors
;; These colors are applied from early-init before the theme is loaded,
;; reducing the white flash on Windows GUI startup. Defaults match ef-dream.
;; For the very first frame, change the defaults in config-org/early-init.org
;; and run `make all`.
;; (setq mcg-initial-frame-background "#232025")
;; (setq mcg-initial-frame-foreground "#efd5c5")

;; Startup loading strategy
;; Module loading strategy is declared in config-org/init.org with `:load'.
;; Supported values are:
;;   immediate - load before private config
;;   idle      - load after the first frame when Emacs is idle
;;   deferred  - load on file trigger from `mcg-module-triggers'
;; Example:
;;   (magit :load idle)
;;   (python :load deferred)

;;; ============================================================
;;; LSP Bridge Configuration
;;; ============================================================

;; Python LSP Server
;; Options: "ty" (ty + ruff), "basedpyright" (basedpyright + ruff)
;; Default: "ty"
;; (setq mcg-lsp-python-server "ty")
;; (setq mcg-lsp-python-server "basedpyright")

;; Python development commands
;; Defaults:
;;   mcg-python-test-command = "python -m pytest"
;;   mcg-python-ruff-command = "ruff"
;;   mcg-python-detect-project-tools = t
;; Projects with uv.lock, poetry.lock, or pdm.lock prefer the matching runner
;; when the executable is available.
;; (setq mcg-python-test-command "python -m pytest")
;; (setq mcg-python-ruff-command "ruff")
;; (setq mcg-python-detect-project-tools nil)

;; Use biome for Web development (instead of ESLint)
;; Default: nil
;; Default formatting prefers project ESLint, especially @antfu/eslint-config.
;; Prettier is only used when the project explicitly declares Prettier.
;; Enable or customize Biome explicitly if a project standardizes on it.
;; (setq mcg-lsp-enable-biome t)

;; Enable lsp-bridge in TRAMP buffers
;; Default: t
;; (setq mcg-lsp-enable-with-tramp nil)

;; Enable inlay hints
;; Default: nil
;; (setq mcg-lsp-enable-inlay-hint t)

;; LSP Bridge side effects are opt-in
;; Default: nil
;; Keep these disabled unless a project wants lsp-bridge to own formatting or
;; Org Babel LSP support.
;; (setq mcg-lsp-enable-auto-format-code t)
;; (setq mcg-lsp-enable-org-babel t)

;; Enable Vale prose diagnostics
;; Default: nil
;; (setq mcg-vale-enable t)
;; (setq mcg-vale-command "vale")

;; Enable Zig LSP when zls is available
;; Default: mcg-zig-enable-lsp = t
;; Default: mcg-zig-warn-missing-zls = nil
;; (setq mcg-zig-enable-lsp nil)
;; (setq mcg-zig-warn-missing-zls t)

;;; ============================================================
;;; UI Configuration
;;; ============================================================

;; Theme (ef-themes)
;; Available themes: ef-dream, ef-winter, ef-light, ef-dark, etc.
;; Default: 'ef-dream
;; (setq mcg-ui-theme 'ef-winter)

;; Awesome Tray position
;; Options: 'left, 'center, 'right
;; Default: 'center
;; (setq mcg-awesome-tray-position 'left)

;; Awesome Tray active modules
;; Default: (quote (mode process gc))
;; (setq mcg-awesome-tray-active-modules '(mode process gc mal))

;; Font configuration
;; Default: auto-detect
;; (setq mcg-font-default-candidates '("JetBrains Mono" "Fira Code"))

;; Dashboard startup screen
;; Dashboard module is disabled by default in config-org/init.org so startup
;; opens the standard *scratch* buffer. Change -dashboard to dashboard there
;; before using these options.
;; Module defaults: enabled, shown at startup, icons prefer nerd-icons.
;; Agenda is not included by default to keep startup light.
;; (setq mcg-dashboard-enabled t)
;; (setq mcg-dashboard-startup t)
;; (setq mcg-dashboard-icon-type 'nerd-icons)
;; (setq mcg-dashboard-startup-banner 'ascii)
;; (setq mcg-dashboard-banner-ascii
;;       (concat
;;        " _      ____  _____ _____ _      ____  ____  ____ \n"
;;        "/ \\__/|/   _\\/  __//  __// \\__/|/  _ \\/   _\\/ ___\\\n"
;;        "| |\\/|||  /  | |  _|  \\  | |\\/||| / \\||  /  |    \\\n"
;;        "| |  |||  \\_ | |*//|  /* | |  ||| |-|||  \\_ \\___ |\n"
;;        "\\_/  \\|\\____/\\____\\\\____\\\\_/  \\|\\_/ \\|\\____/\\____/\n"
;;        "                                                  "))
;; (setq mcg-dashboard-banner-title nil)
;; (setq mcg-dashboard-footer-messages '("By mcge"))
;; (setq mcg-dashboard-items
;;       '((recents . 5)
;;         (projects . 5)
;;         (bookmarks . 5)))
;; (setq mcg-dashboard-nerd-icons-heading-icons
;;       '((recents . "nf-oct-history")
;;         (bookmarks . "nf-oct-bookmark")
;;         (agenda . "nf-oct-calendar")
;;         (projects . "nf-oct-rocket")
;;         (registers . "nf-oct-database")))

;;; ============================================================
;;; Editor Configuration
;;; ============================================================

;; Auto-save idle time (seconds)
;; Default: 1
;; (setq mcg-auto-save-idle 2)

;; Delete trailing whitespace on save
;; Default: nil
;; (setq mcg-auto-save-delete-trailing-whitespace t)

;;; ============================================================
;;; Org Configuration
;;; ============================================================

;; Org storage root
;; Use this helper instead of setting `mcg-org-directory' alone.
;; It refreshes the agenda, notes, capture, diary, billing, password,
;; and `org-agenda-files' paths derived from the root directory.
;; (mcg-org-set-storage-root "~/org/")

;; Hugo integration is opt-in
;; Default: nil
;; (setq mcg-org-hugo-enable t)

;; Hugo blog directory
;; Blog capture files are created under:
;;   mcg-blog-base-directory / mcg-org-hugo-postdir / YYYY / MM
;; Set `mcg-org-blog-capture-directory' only when you want a custom
;; capture directory unrelated to the Hugo post directory.
;; (setq mcg-blog-base-directory "~/blog")
;; (setq mcg-org-hugo-postdir "content-org")
;; (setq mcg-org-blog-capture-directory nil)

;; Enable mixed-pitch mode
;; Default: nil
;; (setq mcg-org-enable-mixed-pitch t)

;; Enable org-modern
;; Default: t
;; (setq mcg-org-enable-org-modern nil)

;; Folded headline/drawer ellipsis
;; Default is ASCII-safe to avoid missing-glyph boxes on Windows.
;; (setq mcg-org-ellipsis " ...")

;; Org TODO keywords and colors
;; Defaults keep the built-in MCG workflow. Override both lists together when
;; adding states such as NEXT, DOING, BLOCKED, or CANCEL.
;; (setq mcg-org-todo-keywords
;;       '((sequence
;;          "TODO(t)" "HOLD(h!)" "WIP(i!)" "WAIT(w!)"
;;          "|"
;;          "DONE(d!)" "CANCELLED(c@/!)")
;;         (sequence
;;          "REPORT(r)" "BUG(b)" "KNOWNCAUSE(k)"
;;          "|"
;;          "FIXED(f!)")))
;; (setq mcg-org-todo-keyword-faces
;;       '(("TODO"      :foreground "#7c7c75" :weight bold)
;;         ("HOLD"      :foreground "#feb24c" :weight bold)
;;         ("WIP"       :foreground "#0098dd" :weight bold)
;;         ("WAIT"      :foreground "#9f7efe" :weight bold)
;;         ("DONE"      :foreground "#50a14f" :weight bold)
;;         ("CANCELLED" :foreground "#ff6480" :weight bold)))
;; (setq mcg-org-modern-todo-faces
;;       '(("TODO" :inverse-video t :inherit org-todo)
;;         ("HOLD" :inverse-video t)
;;         ("WIP" :inverse-video t)
;;         ("WAIT" :inverse-video t)
;;         ("DONE" :inverse-video t :inherit org-done)
;;         ("CANCELLED" :inverse-video t)))

;; Enable org-appear
;; Default: t
;; (setq mcg-org-enable-org-appear nil)

;; Enable visual-fill-column in Org buffers
;; Default: nil
;; (setq mcg-org-enable-visual-fill t)
;; (setq mcg-org-visual-fill-width 88)

;; Enable org-numbering in Org buffers
;; Default: nil
;; (setq mcg-org-enable-org-numbering t)

;; Org download clipboard image defaults
;; Images are saved beside the current Org file under:
;;   <org-file-name>.assets/
;; Default width: 800; default directory suffix: ".assets"
;; (setq mcg-org-download-default-image-width 800)
;; (setq mcg-org-download-image-directory-suffix ".assets")

;; Org Babel safety
;; Default: ask before evaluating code blocks; do not evaluate blocks on export.
;; (setq mcg-org-babel-confirm-evaluate t)
;; (setq mcg-org-export-babel-evaluate nil)

;; Org Babel languages
;; Conservative defaults keep the executable surface small.
;; Zig is controlled separately because this config defines a custom executor.
;; (setq mcg-org-babel-load-languages
;;       '((emacs-lisp . t)
;;         (shell . t)
;;         (python . t)
;;         (js . t)
;;         (css . t)
;;         (org . t)))
;; (setq mcg-org-babel-enable-zig t)
;; (setq mcg-org-babel-zig-default-header-args
;;       '((:results . "output")
;;         (:exports . "both")))
;; (setq mcg-org-babel-src-block-languages
;;       '("emacs-lisp" "python" "shell" "zig" "js" "css" "org"))

;; Extended Org Babel languages
;; Add these only for projects that need the corresponding tools and trust model.
;; (setq mcg-org-babel-load-languages
;;       (append mcg-org-babel-load-languages
;;               '((C . t)
;;                 (dot . t)
;;                 (plantuml . t)
;;                 (sql . t))))
;; (setq mcg-org-babel-src-block-languages
;;       (append mcg-org-babel-src-block-languages
;;               '("C" "dot" "plantuml" "sql")))

;; Agenda calendar location (for sunrise/sunset)
;; Defaults are near Beijing/Tianjin.
;; (setq mcg-calendar-location-longitude 116.9962)
;; (setq mcg-calendar-location-latitude 39.91)

;; Agenda display and time grid
;; Defaults keep the built-in MCG agenda layout.
;; (setq mcg-org-agenda-use-time-grid t)
;; (setq mcg-org-agenda-current-time-string "⏰------------now")
;; (setq mcg-org-agenda-tags-column -80)
;; (setq mcg-org-agenda-sticky t)
;; (setq mcg-org-deadline-warning-days 3)

;; Agenda custom commands
;; Override this when you want a smaller or project-specific agenda menu.
;; (setq mcg-org-agenda-custom-commands
;;       '(("d" "Daily agenda and all TODOs"
;;          ((agenda "" ((org-agenda-span 'day)))
;;           (alltodo "" ((org-agenda-overriding-header "All TODOs")))))))

;;; ============================================================
;;; Local Configuration
;;; ============================================================

;; Machine-local settings and secrets should live in one file:
;;
;;   site-lisp/config/private/config.el
;;
;; That file is ignored by git and loaded automatically by the main init loader.
;;
;; Example private/config.el:
;;
;;   ;; -*- lexical-binding: t; -*-
;;   (setq mcg-lsp-enable-inlay-hint t)
;;   (mcg-org-set-storage-root "D:/workspaces/org")
;;   (setq mcg-blog-base-directory "D:/workspaces/blog/mcge-blog")
;;   (setq mcg-org-hugo-postdir "config-org")
;;   (setq mcg-org-blog-capture-directory nil)
;;
;;   (setq mcg-tools-clutch-connections
;;         `(;; PostgreSQL 连接示例
;;           ("dev-pg" . (:backend pg
;;                       :host "localhost"
;;                       :port 5432
;;                       :user "postgres"
;;                       :database "mydb"
;;                       :password ,(or (getenv "MCG_DEV_PG_PASSWORD")
;;                                      (auth-source-pick-first-password
;;                                       :host "localhost"
;;                                       :user "postgres"))))
;;           ("local-sqlite" . (:backend sqlite
;;                              :database "~/.config/myapp/data.db"))))

(provide 'private-config)
;;; config.el ends here
