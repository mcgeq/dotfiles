;;; init.el --- Main initialization for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024 MCG
;; Author: MCG
;; Keywords: configuration, init

;;; Commentary:
;; This is the main entry point for MCG Emacs configuration.
;; It loads core modules in order, sets up the module system,
;; and orchestrates the loading of all enabled modules.
;;

;;; Code:

;; Determine the configuration directory
(defvar mcg-init-file-dir
  (file-name-directory (or load-file-name buffer-file-name))
  "Directory containing init.el.")

;; Add core directory to load-path first
(add-to-list 'load-path (expand-file-name "core" mcg-init-file-dir))

;; Load core modules in order
;; 1. core-bootstrap: paths, GC optimization, logging
(require 'core-bootstrap)

;; Initialize paths based on init.el location
;; init.el is at: emacs/site-lisp/config/init.el
;; We need to go up two levels to get emacs/ directory
;; config/ -> site-lisp/ -> emacs/
(let* ((config-dir (file-name-as-directory mcg-init-file-dir))
       ;; Remove trailing slash, then get parent directory
       (site-lisp-dir (file-name-directory (directory-file-name config-dir)))
       (emacs-dir (file-name-directory (directory-file-name site-lisp-dir))))
  (mcg-init-paths emacs-dir))

;; Setup load-path for all modules and extensions
(mcg-setup-load-path)

;; Setup GC optimization
(mcg-setup-gc-optimization)

;; 2. core-lib: extension cache, keybinding registry
(require 'core-lib)
(mcg-lib-init)

;; 3. core-modules: module system, mcg! macro
(require 'core-modules)
(mcg-modules-init)

;; 4. core-doctor: configuration diagnostics
(require 'core-doctor)

;; 5. core-autoload: autoload generation (optional)
(when (locate-library "core-autoload")
  (require 'core-autoload nil t))

;; Declare which modules to enable using mcg! macro
;; Modules prefixed with `-' are disabled
;; Modules can declare loading strategy with `:load':
;;   immediate - load during startup before private config
;;   idle      - load after the first frame when Emacs is idle
;;   deferred  - load on file trigger from `mcg-module-triggers'
;;
;; Categories:
;;   :ui         - Theme, modeline, fonts, icons
;;   :editor     - Editor defaults, navigation, editing tools
;;   :completion - Vertico, snippets
;;   :tools      - Git, search, input method, tabs, shell
;;   :enhance    - Auto-save, which-key, helpful, recentf
;;   :org        - Org-mode configuration
;;   :writing    - Markdown, grammar checking
 ;;   :lang       - LSP and language-specific modules
 ;;   :org        - Org-mode configuration

(mcg!
 ;; UI modules
 :ui
 font
 ef-themes
 nerd-icons
 -dashboard
 pulsar
 (holo-layer :load idle)
 (awesome-tray :load idle)

 ;; Editor modules
 :editor
 defaults
 hl-todo
 ibuffer
 (vundo :load idle)
 mwim
 treesit
 format
 (dirvish :load idle)

 ;; Org
 :org
 (org :load idle)

 ;; Completion modules
 :completion
 consult
 marginalia
 vertico
 orderless
 embark
 pinyinlib
 nerd-icons-completion
 (yasnippet :load idle)

 ;; Tools modules
 :tools
 project
 (compile :load idle)
 diagnostics
 posframe
 sort-tab
 auto-save
 (blink-search :load idle)
 (magit :load idle)
 (clutch :load idle)
 (lsp-bridge :load idle)
 (color-rg :load idle)
 (majutsu :load idle)

 ;; Enhance
 :enhance
 help
 recentf

 ;; Writing
 :writing
 (markdown :load deferred)
 (vale :load idle)

 ;; Lang
 :lang
 (python :load deferred)
 (zig :load deferred)
 (web :load deferred)
 )

;; Loading strategy is declared per module in `mcg!' with `:load'.
;; Bare module declarations default to `immediate'.

(defun mcg--idle-module-command-entries-enabled-p (category module)
  "Return non-nil when MODULE in CATEGORY should expose lazy command entries."
  (and (mcg-module-enabled-p category module)
       (eq (mcg-module-load-strategy category module) 'idle)))

(defun mcg--bind-idle-module-command-entries (category module source bindings)
  "Bind lazy command entry BINDINGS for idle MODULE in CATEGORY.
BINDINGS is an alist of (KEY . COMMAND)."
  (when (mcg--idle-module-command-entries-enabled-p category module)
    (dolist (binding bindings)
      (mcg-bind-lazy-module-key
       (car binding) (cdr binding) source category module))))

(defun mcg-setup-idle-module-command-entries ()
  "Expose high-value commands from idle modules immediately."
  (when (mcg--idle-module-command-entries-enabled-p :tools 'compile)
    (define-prefix-command 'mcg-compile-map)
    (mcg-bind-key "C-c c" 'mcg-compile-map "tools/compile")
    (mcg--bind-idle-module-command-entries
     :tools 'compile "tools/compile"
     '(("C-c c c" . mcg-compile)
       ("C-c c r" . mcg-recompile)
       ("C-c c b" . mcg-compile-build)
       ("C-c c t" . mcg-compile-test)
       ("C-c c R" . mcg-compile-run)
       ("M-g e" . mcg-compile-errors))))

  (mcg--bind-idle-module-command-entries
   :tools 'blink-search "tools/blink-search"
   '(("C-c s b" . blink-search)
     ("C-c s d" . mcg/blink-search-grep-current-dir)
     ("C-c s p" . mcg/blink-search-project-root)))

  (mcg--bind-idle-module-command-entries
   :tools 'color-rg "tools/color-rg"
   '(("C-c s g" . color-rg-search-input)
     ("C-c s G" . mcg/color-rg-search-project)
     ("C-c s s" . color-rg-search-symbol)
     ("C-c s S" . mcg/color-rg-search-symbol-in-project)))

  (mcg--bind-idle-module-command-entries
   :tools 'magit "tools/magit"
   '(("C-x g" . magit-status)
     ("C-x M-g" . magit-dispatch)
     ("C-c g s" . magit-status)
     ("C-c g l" . magit-log)
     ("C-c g d" . magit-dispatch)
     ("C-c g f" . magit-file-dispatch)
     ("C-c g ?" . mcg/magit-menu)))

  (mcg--bind-idle-module-command-entries
   :editor 'dirvish "editor/dirvish"
   '(("C-c d" . dirvish)))

  (mcg--bind-idle-module-command-entries
   :tools 'clutch "tools/clutch"
   '(("C-c ; c" . clutch-query-console)
     ("C-c ; j" . clutch-jump)
     ("C-c ; t" . clutch-list-tables)
     ("C-c ; s" . clutch-show-schema)
     ("C-c ; R" . clutch-recent)
     ("C-c ; ?" . clutch-dispatch)))

  (mcg--bind-idle-module-command-entries
   :tools 'majutsu "tools/majutsu"
   '(("C-x M-j" . majutsu)))

  (mcg--bind-idle-module-command-entries
   :org 'org "org/capture"
   '(("C-c n c" . org-capture)
     ("C-c n a" . org-agenda)
     ("C-c n l" . org-store-link)
     ("C-c n t" . org-todo-list)))

  (mcg--bind-idle-module-command-entries
   :editor 'vundo "editor/vundo"
   '(("C-x u" . vundo)
     ("C-c u" . vundo)
     ("C-/" . vundo))))

(defun mcg-load-immediate-modules ()
  "Load all modules declared with `:load immediate'."
  (dolist (mod-key (mcg-list-modules-by-load-strategy 'immediate))
    (mcg-load-module (car mod-key) (cdr mod-key))))

(defun mcg-setup-idle-modules ()
  "Set up idle loading for modules declared with `:load idle'."
  (dolist (mod-key (reverse (mcg-list-modules-by-load-strategy 'idle)))
    (mcg-add-idle-load-module (car mod-key) (cdr mod-key)))
  (mcg-setup-idle-loading))

(defun mcg-setup-deferred-modules ()
  "Set up trigger-based loading for modules declared with `:load deferred'."
  (dolist (mod-key (mcg-list-modules-by-load-strategy 'deferred))
    (mcg-defer-module (car mod-key) (cdr mod-key))))

(defun mcg-load-private-file (filename profile-name)
  "Load private FILENAME under `mcg-private-dir' using PROFILE-NAME."
  (let ((private-file (expand-file-name filename mcg-private-dir)))
    (when (file-exists-p private-file)
      (condition-case err
          (progn
            (mcg-profile profile-name
              (load private-file nil t))
            (mcg-log "Loaded %s" profile-name))
        (error
         (mcg-log-error "Failed to load %s: %s"
                        profile-name
                        (error-message-string err)))))))

(defun mcg-load-private-config ()
  "Load private config."
  (mcg-load-private-file "config.el" "private/config"))

(defun mcg-display-startup-stats ()
  "Display startup statistics after Emacs is ready."
  (let ((loaded-count (length mcg-loaded-modules))
        (deferred-count (length mcg-deferred-modules))
        (idle-count (length mcg-idle-load-modules))
        (error-count (length mcg-module-load-errors)))
    (mcg-log "Startup complete: %d loaded, %d deferred, %d idle, %d errors"
             loaded-count deferred-count idle-count error-count)
    ;; Show errors if any
    (when (> error-count 0)
      (mcg-log-warning "Module load errors occurred. Run M-x mcg-list-modules to see details."))))

(defun mcg-init ()
  "Main initialization function.
Called to set up the complete MCG Emacs configuration."
  ;; Expose selected idle-module commands without paying their startup cost.
  (mcg-setup-idle-module-command-entries)

  ;; Load immediate modules (UI, editor, tools, org)
  (mcg-load-immediate-modules)

  ;; Setup idle loading for completion and enhance modules
  (mcg-setup-idle-modules)

  ;; Setup deferred loading for writing and language modules
  (mcg-setup-deferred-modules)

  ;; Load private configuration last
  (mcg-load-private-config)

  ;; Display startup statistics
  (add-hook 'emacs-startup-hook #'mcg-display-startup-stats 95))

;; Run initialization
(mcg-init)

;; Additional setup after Emacs is fully started
(add-hook 'emacs-startup-hook
          (lambda ()
            ;; Restore GC settings (handled by core-bootstrap)
            ;; Display startup time (handled by core-bootstrap)

            ;; Any additional post-startup setup can go here
            (mcg-log "MCG Emacs ready"))
          100)

(provide 'init)
;;; init.el ends here
