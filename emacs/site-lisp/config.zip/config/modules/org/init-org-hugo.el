;;; init-org-hugo.el --- Hugo Blog Integration for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, hugo, blog, ox-hugo, easy-hugo
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Hugo blog integration module for MCG Emacs, combining:
;; - easy-hugo for blog management
;; - ox-hugo for Org to Hugo export
;; - org-capture templates for Hugo posts

;;; Code:

(require 'core-lib)
(require 'org-capture)
(require 'init-org-capture)
(require 'subr-x)

;;; ============================================================
;;; Variables
;;; ============================================================

(defgroup mcg-org-hugo nil
  "Hugo blog configuration variables."
  :group 'mcg-org
  :prefix "mcg-org-hugo-")

(defcustom mcg-blog-base-directory
  (expand-file-name "~/blog")
  "Hugo blog root directory."
  :type 'directory
  :group 'mcg-org-hugo)

(defcustom mcg-org-hugo-enable nil
  "Whether to enable optional Hugo blog integration."
  :type 'boolean
  :group 'mcg-org-hugo)

(defcustom mcg-org-hugo-url "https://www.gemc.club"
  "Hugo blog URL."
  :type 'string
  :group 'mcg-org-hugo)

(defcustom mcg-org-hugo-postdir "content-org"
  "Hugo content directory (relative to blog base)."
  :type 'string
  :group 'mcg-org-hugo)

(defcustom mcg-org-hugo-default-ext ".org"
  "Default file extension for Hugo posts."
  :type 'string
  :group 'mcg-org-hugo)

(defcustom mcg-org-blog-development-file
  (expand-file-name "development.org" (expand-file-name "blog" mcg-org-directory))
  "Development blog org file."
  :type 'file
  :group 'mcg-org-hugo)

(defcustom mcg-org-blog-emacs-file
  (expand-file-name "emacs.org" (expand-file-name "blog" mcg-org-directory))
  "Emacs blog org file."
  :type 'file
  :group 'mcg-org-hugo)

(defcustom mcg-org-blog-capture-directory
  nil
  "Directory for one-file-per-capture blog posts.

When nil, use `mcg-blog-base-directory' plus `mcg-org-hugo-postdir'."
  :type '(choice (const :tag "Use Hugo post directory" nil)
                 directory)
  :group 'mcg-org-hugo)

;;; ============================================================
;;; Easy Hugo Configuration
;;; ============================================================

(defun mcg-org-hugo-setup-easy-hugo ()
  "Set up easy-hugo for blog management."
  (when (and mcg-org-hugo-enable
             (mcg-require-extension "easy-hugo" t))
    (setq easy-hugo-postdir mcg-org-hugo-postdir
          easy-hugo-default-ext mcg-org-hugo-default-ext
          easy-hugo-url mcg-org-hugo-url
          easy-hugo-basedir (file-name-as-directory mcg-blog-base-directory))
    (mcg-log "Easy Hugo configured: %s" mcg-blog-base-directory)))

;;; ============================================================
;;; Ox Hugo Configuration
;;; ============================================================

(defun mcg-org-hugo-setup-ox-hugo ()
  "Set up ox-hugo for Org to Hugo export."
  (when (and mcg-org-hugo-enable
             (mcg-require-extension "ox-hugo" t))
    (setq org-hugo-base-dir (file-name-as-directory mcg-blog-base-directory))
    (mcg-log "Ox Hugo configured")))

;;; ============================================================
;;; Hugo Capture Templates
;;; ============================================================

(defvar mcg-org-hugo-capture--state nil
  "Metadata collected while resolving a Hugo capture target file.")

(defun mcg-org-hugo-capture-reset-state ()
  "Clear transient metadata collected during Hugo capture."
  (setq mcg-org-hugo-capture--state nil))

(defun mcg-org-hugo--slugify (value)
  "Return a Hugo-friendly slug for VALUE."
  (if (fboundp 'org-hugo-slug)
      (org-hugo-slug value)
    (mcg-org-capture-slugify-filename value)))

(defun mcg-org-hugo--blank-value-p (value)
  "Return non-nil when VALUE should be treated as empty."
  (let ((text (string-trim (format "%s" (or value "")))))
    (or (string-empty-p text)
        (string= text "undefined"))))

(defun mcg-org-hugo--clean-value (value fallback)
  "Return VALUE as a trimmed string, or FALLBACK when VALUE is blank."
  (if (mcg-org-hugo--blank-value-p value)
      fallback
    (string-trim (format "%s" value))))

(defun mcg-org-hugo--read-capture-state ()
  "Read Hugo capture title and file name, then store them."
  (let* ((title (mcg-org-hugo--clean-value
                 (read-string "Post Title: ") "Untitled"))
         (file-name (mcg-org-hugo--clean-value
                     (read-string "Slug/File name (empty to auto): ") ""))
         (slug-source (if (mcg-org-hugo--blank-value-p file-name)
                          title
                        file-name))
         (slug (mcg-org-hugo--slugify slug-source)))
    (setq mcg-org-hugo-capture--state
          (list :title title
                :file-name file-name
                :slug slug))))

(defun mcg-org-hugo--ensure-capture-state ()
  "Return current Hugo capture state, prompting when missing."
  (unless (and (plist-member mcg-org-hugo-capture--state :title)
               (plist-member mcg-org-hugo-capture--state :slug))
    (mcg-org-hugo--read-capture-state))
  mcg-org-hugo-capture--state)

(defun mcg-org-hugo-capture-directory ()
  "Return the directory where Hugo capture files should be created."
  (file-name-as-directory
   (or mcg-org-blog-capture-directory
       (expand-file-name mcg-org-hugo-postdir mcg-blog-base-directory))))

(defun mcg-org-hugo-capture-post-file ()
  "Return a new one-file-per-capture Hugo post file."
  (let* ((state (mcg-org-hugo--ensure-capture-state))
         (title (plist-get state :title))
         (file-name (plist-get state :file-name))
         (file (mcg-org-capture-build-file
                (mcg-org-hugo-capture-directory) nil title file-name)))
    (make-directory (file-name-directory file) t)
    file))

(defun mcg/org-hugo-new-subtree-post-capture-template ()
  "Return org-capture template string for new Hugo post."
  (let* ((state (mcg-org-hugo--read-capture-state))
         (date (format-time-string (org-time-stamp-format :long :inactive)))
         (title (mcg-org-hugo--clean-value
                 (plist-get state :title)
                 "Untitled"))
         (fname (mcg-org-hugo--clean-value
                 (plist-get state :slug)
                 (mcg-org-hugo--slugify title)))
         (description (mcg-org-hugo--clean-value
                       (read-from-minibuffer "Description: ") ""))
         (categories (mcg-org-hugo--clean-value
                      (read-from-minibuffer "Categories (space separated): ")
                      ""))
         (tags (mcg-org-hugo--clean-value
                (read-from-minibuffer "Tags (space separated): ") "")))
    (mapconcat #'identity
               (delq nil
                     `(,(concat "#+title: " title)
                       ,(concat "#+date: " date)
                       ,(concat "#+hugo_base_dir: "
                                (file-name-as-directory mcg-blog-base-directory))
                       ,(concat "#+hugo_section: "
                                (file-name-as-directory mcg-org-hugo-postdir))
                       ,(concat "#+hugo_slug: " fname)
                       ,(unless (string= description "")
                          (concat "#+description: " description))
                       ,(unless (string= categories "")
                          (concat "#+hugo_categories: " categories))
                       ,(unless (string= tags "")
                          (concat "#+hugo_tags: " tags))
                       "#+hugo_custom_front_matter: :image \"\" :hideFromHomePage false"
                       ""
                       "* TODO Draft"
                       "%?\n"))
               "\n")))

;;; ============================================================
;;; Hugo Integration
;;; ============================================================

(defun mcg-org-hugo-setup-capture-templates ()
  "Setup Hugo blog capture templates."
  (when mcg-org-hugo-enable
    ;; Add Hugo post category
    (add-to-list 'org-capture-templates '("h" "Hugo Post"))

    ;; One-file-per-post blog template. Category and tags are entered
    ;; during capture, so topic-specific shortcuts are intentionally omitted.
    (add-to-list 'org-capture-templates
                 `("hb" "Blog Post"
                   plain
                   (file (lambda ()
                           (mcg-org-hugo-capture-post-file)))
                   (function mcg/org-hugo-new-subtree-post-capture-template)
                   :jump-to-captured t
                   :unnarrowed t))

    (add-hook 'org-capture-after-finalize-hook
              #'mcg-org-hugo-capture-reset-state)
    (mcg-log "Hugo capture templates configured")))

;;; ============================================================
;;; Initialize
;;; ============================================================

(defun mcg-org-hugo-init ()
  "Initialize Hugo blog integration."
  (when mcg-org-hugo-enable
    (mcg-org-hugo-setup-easy-hugo)
    (mcg-org-hugo-setup-ox-hugo)
    (mcg-org-hugo-setup-capture-templates)))

(mcg-org-hugo-init)

(provide 'init-org-hugo)
;;; init-org-hugo.el ends here
