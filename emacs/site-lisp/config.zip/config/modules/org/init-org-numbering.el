;;; init-org-numbering.el --- Org Numbering for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, org-numbering

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Configuration
;;; ============================================================

(defcustom mcg-org-enable-org-numbering nil
  "Whether to enable org-numbering in Org buffers."
  :type 'boolean
  :group 'mcg-org)

(defun mcg-org-numbering-enable ()
  "Enable org-numbering in the current buffer."
  (org-numbering-mode 1))

(defun mcg--setup-org-numbering ()
  "Set up org-numbering."
  (with-eval-after-load 'org
    (when (and mcg-org-enable-org-numbering
               (mcg-require-extension "org-numbering" t))
      (add-hook 'org-mode-hook #'mcg-org-numbering-enable)
      (mcg-log "Org numbering configured"))))

(mcg--setup-org-numbering)

(provide 'init-org-numbering)
;;; init-org-numbering.el ends here
