;;; init-ox-gfm.el --- Ox GFM for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, ox-gfm, markdown

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Configuration
;;; ============================================================

(defun mcg--setup-ox-gfm ()
  "Set up ox-gfm."
  (when (mcg-require-extension "ox-gfm" t)
    (mcg-log "Ox gfm configured")))

(mcg--setup-ox-gfm)

(provide 'init-ox-gfm)
;;; init-ox-gfm.el ends here
