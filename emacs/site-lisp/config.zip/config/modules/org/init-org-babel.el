;;; init-org-babel.el --- Org Babel for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, babel, literate-programming

;;; Code:

(require 'core-lib)
(require 'org)
(require 'ob-core)
(require 'ob-tangle)

;;; ============================================================
;;; Basic Configuration
;;; ============================================================

(defcustom mcg-org-babel-confirm-evaluate t
  "Whether Org should ask before evaluating Babel code blocks."
  :type 'boolean
  :group 'mcg-org)

(defcustom mcg-org-export-babel-evaluate nil
  "Whether Org export should evaluate Babel code blocks."
  :type 'boolean
  :group 'mcg-org)

(defcustom mcg-org-babel-load-languages
  ;; Conservative default languages: keep the common literate config and
  ;; day-to-day scripting surface small. Extended Babel languages such as C,
  ;; dot, plantuml, and sql can be enabled from private config when needed.
  '((emacs-lisp . t)
    (shell . t)
    (python . t)
    (js . t)
    (css . t)
    (org . t))
  "Languages enabled for Org Babel.
Zig is controlled separately by `mcg-org-babel-enable-zig'."
  :type '(repeat (cons symbol boolean))
  :group 'mcg-org)

(defcustom mcg-org-babel-enable-zig t
  "Whether to enable the custom Zig Org Babel executor."
  :type 'boolean
  :group 'mcg-org)

(defcustom mcg-org-babel-zig-default-header-args
  '((:results . "output")
    (:exports . "both"))
  "Default header arguments for Zig Org Babel blocks."
  :type 'sexp
  :group 'mcg-org)

(defcustom mcg-org-babel-src-block-languages
  '("emacs-lisp" "python" "shell" "zig" "js" "css" "org")
  "Language candidates offered by `mcg/org-insert-src-block'."
  :type '(repeat string)
  :group 'mcg-org)

(defun mcg-org-babel-setup-basic ()
  "Setup Org Babel basic configuration."
  (setq org-confirm-babel-evaluate mcg-org-babel-confirm-evaluate
        org-src-fontify-natively t
        org-src-tab-acts-natively t
        org-src-preserve-indentation t
        org-edit-src-content-indentation 0)
  (setq org-src-window-setup 'current-window)
  (setq org-export-use-babel t
        org-export-babel-evaluate mcg-org-export-babel-evaluate)
  (mcg-log "Configured org-babel basic settings"))

;;; Language Support

(defun mcg-org-babel-setup-languages ()
  "Setup Org Babel language support."
  (with-eval-after-load 'org
    (org-babel-do-load-languages
     'org-babel-load-languages
     mcg-org-babel-load-languages)
    (mcg-log "Configured org-babel languages")))

;;; Default Arguments

(defun mcg-org-babel-setup-defaults ()
  "Setup Org Babel default arguments."
  (setq org-babel-default-header-args
        '((:session . "none")
          (:results . "replace")
          (:exports . "code")
          (:cache . "no")
          (:noweb . "no")
          (:hlines . "no")
          (:tangle . "no")))
  (setq org-babel-default-header-args:python
        '((:results . "output")))
  (setq org-babel-default-header-args:shell
        '((:results . "output")))
  (mcg-log "Configured org-babel default arguments"))

;;; Zig Language Support

(defvar org-babel-default-header-args:zig '()
  "Default arguments for Zig code blocks.")

(defun org-babel-execute:zig (body params)
  "Execute Zig code block.
BODY is the code content, PARAMS are the parameters."
  (let* ((tmp-src-file (org-babel-temp-file "zig-src-" ".zig"))
         (tmp-bin-file (org-babel-temp-file "zig-bin-"))
         (cmdline (cdr (assq :cmdline params)))
         (flags (cdr (assq :flags params)))
         (full-body (org-babel-expand-body:generic body params)))

    (unless (executable-find "zig")
      (error "Zig compiler not found"))

    (with-temp-file tmp-src-file
      (insert full-body))

    (let ((compile-command
           (format "zig build-exe %s %s -femit-bin=%s"
                   (or flags "")
                   (org-babel-process-file-name tmp-src-file)
                   (org-babel-process-file-name tmp-bin-file)))
          (run-command
           (format "%s %s"
                   (org-babel-process-file-name tmp-bin-file)
                   (or cmdline ""))))

      (let ((compile-result (org-babel-eval compile-command "")))
        (if (string-match-p "error" compile-result)
            (concat "Compilation failed:\n" compile-result)
          (org-babel-eval run-command ""))))))

(defun mcg-org-babel-setup-zig ()
  "Setup Zig language support."
  (with-eval-after-load 'org
    (when mcg-org-babel-enable-zig
      (add-to-list 'org-babel-load-languages '(zig . t))
      (setq org-babel-default-header-args:zig
            mcg-org-babel-zig-default-header-args)
      (mcg-log "Configured org-babel Zig support"))))

;;; Helper Functions

(defun mcg/org-babel-execute-buffer ()
  "Execute all code blocks in current buffer."
  (interactive)
  (org-babel-execute-buffer)
  (message "Executed all code blocks in buffer"))

(defun mcg/org-babel-tangle-and-compile ()
  "Tangle current file."
  (interactive)
  (org-babel-tangle)
  (message "Tangled file"))

(defun mcg/org-babel-remove-all-results ()
  "Remove all code block results in current buffer."
  (interactive)
  (org-babel-remove-result-one-or-many t)
  (message "Removed all results"))

(defun mcg/org-insert-src-block (lang)
  "Insert a code block for the specified language LANG."
  (interactive
   (list (completing-read "Language: "
                          mcg-org-babel-src-block-languages
                          nil nil)))
  (insert (format "#+begin_src %s\n\n#+end_src" lang))
  (forward-line -1))

;;; Keybindings

(defun mcg-org-babel-setup-keybindings ()
  "Setup Org Babel keybindings."
  (with-eval-after-load 'org
    (define-key org-mode-map (kbd "C-c C-v C-b") #'mcg/org-babel-execute-buffer)
    (define-key org-mode-map (kbd "C-c C-v C-r") #'mcg/org-babel-remove-all-results)
    (define-key org-mode-map (kbd "C-c C-v i") #'mcg/org-insert-src-block))
  (mcg-log "Configured org-babel keybindings"))

;;; Initialize

(mcg-org-babel-setup-basic)
(mcg-org-babel-setup-defaults)

(add-hook 'org-mode-hook
          (lambda ()
            (mcg-org-babel-setup-languages)
            (mcg-org-babel-setup-zig)))

(mcg-org-babel-setup-keybindings)

(provide 'init-org-babel)
;;; init-org-babel.el ends here
