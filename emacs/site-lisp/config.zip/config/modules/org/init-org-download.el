;;; init-org-download.el --- Org Download for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, org-download

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Configuration
;;; ============================================================

(defcustom mcg-org-download-default-image-width 800
  "Default image display width for clipboard images inserted into Org."
  :type 'integer
  :group 'mcg-org)

(defcustom mcg-org-download-image-directory-suffix ".assets"
  "Suffix appended to the Org file base name for image assets."
  :type 'string
  :group 'mcg-org)

(defun mcg--setup-org-download ()
  "Set up org-download."
  (with-eval-after-load 'org
    (when (mcg-require-extension "org-download" t)
      (add-hook 'dired-mode-hook 'org-download-enable)
      (add-hook 'org-mode-hook 'org-download-enable)
      (setq org-download-display-inline-images 'posframe)
      (mcg-log "Org download configured"))))

;;; Clipboard Image Function

(defun mcg-org-download--org-file-name (&optional org-file)
  "Return ORG-FILE or the current buffer file name.
Signal a user-facing error when there is no saved Org file."
  (let ((file (or org-file buffer-file-name)))
    (unless (and file (not (string= file "")))
      (user-error "Save current Org buffer before inserting images"))
    (expand-file-name file)))

(defun mcg-org-download-assets-directory (&optional org-file)
  "Return the image assets directory for ORG-FILE or current Org buffer."
  (let ((file (mcg-org-download--org-file-name org-file)))
    (expand-file-name
     (concat (file-name-base file) mcg-org-download-image-directory-suffix)
     (file-name-directory file))))

(defun mcg-org-download-image-file (image-name &optional org-file)
  "Return absolute image path for IMAGE-NAME beside ORG-FILE assets."
  (expand-file-name image-name (mcg-org-download-assets-directory org-file)))

(defun mcg-org-download-relative-image-file (image-file &optional org-file)
  "Return IMAGE-FILE as an Org-friendly relative path from ORG-FILE."
  (let* ((file (mcg-org-download--org-file-name org-file))
         (relative (file-relative-name image-file (file-name-directory file))))
    (replace-regexp-in-string "\\\\" "/" relative)))

(defun mcg-org-download-screenshot-method (image-file)
  "Return clipboard screenshot command writing to IMAGE-FILE."
  (let ((quoted-file (shell-quote-argument image-file)))
    (cond
     ((eq system-type 'windows-nt)
      (format "magick clipboard: %s" quoted-file))
     ((eq system-type 'gnu/linux)
      (format "xclip -selection clipboard -t image/png -o > %s" quoted-file))
     ((eq system-type 'darwin)
      (format "pngpaste %s" quoted-file))
     (t
      (user-error "Unsupported system for clipboard image capture: %s"
                  system-type)))))

(defun mcg/org-insert-clipboard-image (width)
  "Insert image from clipboard into Org file.
WIDTH is the image width, default 800.
Images are saved in a .assets directory named after the Org file."
  (interactive (list
                (read-string
                 (format "Input image width, default is %s: "
                         mcg-org-download-default-image-width)
                 nil nil
                 (number-to-string mcg-org-download-default-image-width))))
  (let* ((width (if (string= width "")
                    (number-to-string mcg-org-download-default-image-width)
                  width))
         (image-name (concat "img_" (format-time-string "%Y%m%d_%H%M%S") ".png"))
         (image-file (mcg-org-download-image-file image-name))
         (relative-file (mcg-org-download-relative-image-file image-file)))

    (unless (file-directory-p (file-name-directory image-file))
      (make-directory (file-name-directory image-file) t))

    (setq org-download-screenshot-method
          (mcg-org-download-screenshot-method image-file))

    (insert (concat "\n#+DOWNLOADED: screenshot @ "
                    (format-time-string "%Y-%m-%d %a %H:%M:%S" (current-time))
                    "\n#+CAPTION: \n#+ATTR_ORG: :width "
                    width
                    "\n#+ATTR_LATEX: :width "
                    (if (>= (/ (string-to-number width) 800.0) 1.0)
                        "1.0"
                      (number-to-string (/ (string-to-number width) 800.0)))
                    "\\linewidth :float nil\n"
                    "#+ATTR_HTML: :width "
                    width
                    "\n[[file:" relative-file "]]\n"))

    (when (fboundp 'org-download-screenshot)
      (org-download-screenshot))))

;;; Keybindings

(defun mcg--setup-org-download-keybindings ()
  "Set up org-download keybindings."
  (with-eval-after-load 'org
    (define-key org-mode-map (kbd "C-c n v") 'mcg/org-insert-clipboard-image)))

(mcg--setup-org-download)
(mcg--setup-org-download-keybindings)

(provide 'init-org-download)
;;; init-org-download.el ends here
