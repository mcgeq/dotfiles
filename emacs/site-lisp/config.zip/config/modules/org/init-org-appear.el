;;; init-org-appear.el --- Org Appear for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, org-appear

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Configuration
;;; ============================================================

(defcustom mcg-org-enable-org-appear t
  "Whether to enable org-appear in Org buffers."
  :type 'boolean
  :group 'mcg-org)

(defun mcg-org-appear-enable ()
  "Enable org-appear in the current buffer."
  (org-appear-mode 1))

(defun mcg--setup-org-appear ()
  "Set up org-appear."
  (with-eval-after-load 'org
    (when (and mcg-org-enable-org-appear
               (mcg-require-extension "org-appear" t))
      (setq org-appear-autosubmarkers t
            org-appear-autolinks t)
      (add-hook 'org-mode-hook #'mcg-org-appear-enable)
      (mcg-log "Org appear configured"))))

(mcg--setup-org-appear)

(provide 'init-org-appear)
;;; init-org-appear.el ends here
