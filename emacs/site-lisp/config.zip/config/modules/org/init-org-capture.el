;;; init-org-capture.el --- Org Capture for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, capture

;;; Code:

(require 'core-lib)
(require 'org-capture)
(require 'subr-x)

;;; ============================================================
;;; Variables
;;; ============================================================

(defcustom mcg-org-diary-file
  (expand-file-name "diary.org" mcg-org-agenda-directory)
  "Diary file."
  :type 'file
  :group 'mcg-org)

(defcustom mcg-org-journal-file
  (expand-file-name "journal.org" mcg-org-notes-directory)
  "Journal file."
  :type 'file
  :group 'mcg-org)

(defcustom mcg-org-billing-file
  (expand-file-name "billing.org" mcg-org-notes-directory)
  "Billing file."
  :type 'file
  :group 'mcg-org)

(defcustom mcg-org-password-file
  (expand-file-name "passwords.org" mcg-org-notes-directory)
  "Password management file."
  :type 'file
  :group 'mcg-org)

(defcustom mcg-org-capture-notes-directory
  (expand-file-name "capture" mcg-org-notes-directory)
  "Directory for one-file-per-capture notes."
  :type 'directory
  :group 'mcg-org)

(defcustom mcg-org-capture-journal-directory
  (expand-file-name "journal" mcg-org-notes-directory)
  "Directory for one-file-per-capture journal entries."
  :type 'directory
  :group 'mcg-org)

;;; File Capture Helper Functions

(defvar mcg-org-capture--last-title nil
  "Title collected while resolving an Org capture target file.")

(defun mcg-org-capture-slugify-filename (value)
  "Return a safe, readable Org file base name from VALUE."
  (let* ((name (downcase (string-trim (or value ""))))
         (name (replace-regexp-in-string "[[:space:]\n\r\t]+" "-" name))
         (name (replace-regexp-in-string "[<>:\"/\\\\|?*]+" "-" name))
         (name (replace-regexp-in-string "-+" "-" name))
         (name (string-trim name "-+" "-+")))
    (if (string-empty-p name) "untitled" name)))

(defun mcg-org-capture--timestamp-time (timestamp)
  "Return time object for TIMESTAMP or the current time."
  (if (and timestamp (not (string-empty-p timestamp)))
      (date-to-time timestamp)
    (current-time)))

(defun mcg-org-capture--unique-file (file)
  "Return FILE, or a numbered variant if FILE already exists."
  (let* ((directory (file-name-directory file))
         (extension (file-name-extension file t))
         (base (file-name-base file))
         (candidate file)
         (index 2))
    (while (file-exists-p candidate)
      (setq candidate (expand-file-name
                       (format "%s-%d%s" base index extension)
                       directory))
      (setq index (1+ index)))
    candidate))

(defun mcg-org-capture-build-file (root timestamp title file-name)
  "Build an Org capture file under ROOT using TIMESTAMP, TITLE, and FILE-NAME.

ROOT is organized as YYYY/MM.  FILE-NAME wins when non-empty; otherwise
the generated name uses TIMESTAMP and TITLE."
  (let* ((time (mcg-org-capture--timestamp-time timestamp))
         (directory (expand-file-name
                     (format-time-string "%Y/%m" time)
                     root))
         (base (if (string-empty-p (string-trim (or file-name "")))
                   (format "%s-%s"
                           (format-time-string "%Y%m%d-%H%M%S" time)
                           (mcg-org-capture-slugify-filename title))
                 (mcg-org-capture-slugify-filename file-name)))
         (file (expand-file-name (concat base ".org") directory)))
    (mcg-org-capture--unique-file file)))

(defun mcg-org-capture--target-file (root prompt)
  "Read capture metadata and return a new target file under ROOT.

PROMPT names the title prompt shown to the user."
  (let* ((title (string-trim (read-string prompt)))
         (title (if (string-empty-p title) "Untitled" title))
         (file-name (read-string "File name (empty to auto): "))
         (file (mcg-org-capture-build-file
                root nil title file-name)))
    (setq mcg-org-capture--last-title title)
    (make-directory (file-name-directory file) t)
    file))

(defun mcg-org-capture-note-file ()
  "Return a new one-file-per-capture note file."
  (mcg-org-capture--target-file mcg-org-capture-notes-directory "Title: "))

(defun mcg-org-capture-journal-file ()
  "Return a new one-file-per-capture journal file."
  (mcg-org-capture--target-file mcg-org-capture-journal-directory "Journal title: "))

(defun mcg-org-capture-last-title ()
  "Return the last title read for a dynamic capture target."
  (or mcg-org-capture--last-title "Untitled"))

(defun mcg-org-capture-reset-state ()
  "Clear transient state collected during Org capture."
  (setq mcg-org-capture--last-title nil))

;;; Password Helper Functions

(defun mcg/random-alphanum ()
  "Generate a random alphanumeric character."
  (let* ((charset "abcdefghijklmnopqurstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
         (x (random 62)))
    (char-to-string (elt charset x))))

(defun mcg/create-password ()
  "Generate a 16-character random password."
  (let ((value ""))
    (dotimes (_ 16 value)
      (setq value (concat value (mcg/random-alphanum))))))

(defun mcg/get-or-create-password ()
  "Get or create password."
  (let ((password (read-string "Password: ")))
    (if (string= password "")
        (mcg/create-password)
      password)))

;;; Billing Helper Functions

(defun mcg/get-year-and-month ()
  "Get current year and month (Chinese format)."
  (list (format-time-string "%Y 年") (format-time-string "%m 月")))

(defun mcg/find-month-tree ()
  "Find or create year-month tree structure in Org file."
  (let* ((path (mcg/get-year-and-month))
         (level 1)
         end)
    (unless (derived-mode-p 'org-mode)
      (error "Target buffer should be in Org mode"))
    (goto-char (point-min))
    (dolist (heading path)
      (let ((re (format org-complex-heading-regexp-format
                        (regexp-quote heading))))
        (if (re-search-forward re end t)
            (goto-char (line-beginning-position))
          (progn
            (or (bolp) (insert "\n"))
            (if (/= (point) (point-min)) (org-end-of-subtree t t))
            (insert (make-string level ?*) " " heading "\n"))))
      (setq level (1+ level))
      (setq end (save-excursion (org-end-of-subtree t t))))
    (org-end-of-subtree)))

;;; Basic Configuration

(defun mcg--setup-org-capture ()
  "Setup Org Capture basic configuration."
  (add-hook 'org-capture-mode-hook
            (lambda ()
              (setq-local org-complete-tags-always-offer-all-agenda-tags t)))
  (add-hook 'org-capture-mode-hook 'delete-other-windows)
  (add-hook 'org-capture-after-finalize-hook #'mcg-org-capture-reset-state)
  (setq org-capture-use-agenda-date nil)
  (mcg-log "Org capture basic configuration done"))

;;; Capture Templates

(defun mcg--setup-capture-templates ()
  "Setup Capture templates."
  (setq org-capture-templates nil)

  (add-to-list 'org-capture-templates '("t" "Tasks"))
  (add-to-list 'org-capture-templates
               '("tr" "Book Reading Task"
                 entry (file+olp mcg-org-task-file "Reading Book")
                 "* TODO %^{书名}\n%u\n%a\n"
                 :clock-in t))
  (add-to-list 'org-capture-templates
               '("tw" "Work Task"
                 entry (file+headline mcg-org-task-file "Work")
                 "* TODO %^{任务名}\n%u\n%a\n"
                 :clock-in t :clock-resume t))

  (add-to-list 'org-capture-templates '("d" "Diary"))
  (add-to-list 'org-capture-templates
               '("dt" "Today's TODO List"
                 entry (file+olp+datetree mcg-org-diary-file)
                 "* Today's TODO List [/]\n%T\n\n** TODO %?"
                 :empty-lines 1
                 :jump-to-captured t))
  (add-to-list 'org-capture-templates
               '("do" "Other stuff"
                 entry (file+olp+datetree mcg-org-diary-file)
                 "* %?\n%T\n\n%i"
                 :empty-lines 1
                 :jump-to-captured t))

  (add-to-list 'org-capture-templates
               '("n" "Notes"
                 entry (file mcg-org-capture-note-file)
                 "* %(mcg-org-capture-last-title) %t %^g\n%?\n"
                 :empty-lines 1
                 :jump-to-captured t
                 :unnarrowed t))

  (add-to-list 'org-capture-templates
               '("j" "Journal"
                 entry (file mcg-org-capture-journal-file)
                 "* %U - %(mcg-org-capture-last-title) %^g\n%?\n"
                 :empty-lines 1
                 :jump-to-captured t
                 :unnarrowed t))

  (add-to-list 'org-capture-templates
               '("b" "Billing"
                 plain (file+function mcg-org-billing-file mcg/find-month-tree)
                 " | %U | %^{Category} | %^{Description} | %^{Amount} |"
                 :immediate-finish t
                 :kill-buffer t))

  (add-to-list 'org-capture-templates
               '("p" "Passwords"
                 entry (file mcg-org-password-file)
                 "* %U - %^{title} %^G\n\n - Username: %^{Username}\n - Password: %(mcg/get-or-create-password)"
                 :empty-lines 1
                 :immediate-finish t
                 :kill-buffer t))

  (mcg-log "Capture templates configured"))

;;; Keybindings

(defun mcg--setup-capture-keybindings ()
  "Setup Capture related keybindings."
  (mcg-bind-key "C-c n c" 'org-capture "org/capture")
  (mcg-bind-key "C-c n a" 'org-agenda "org/capture")
  (mcg-bind-key "C-c n l" 'org-store-link "org/capture")
  (mcg-bind-key "C-c n t" 'org-todo-list "org/capture")
  (mcg-log "Capture keybindings configured"))

;;; Initialize

(mcg--setup-org-capture)
(mcg--setup-capture-templates)
(mcg--setup-capture-keybindings)

(provide 'init-org-capture)
;;; init-org-capture.el ends here
