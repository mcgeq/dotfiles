;;; init-org-modern.el --- Org Modern for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, org-modern

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Configuration
;;; ============================================================

(defcustom mcg-org-enable-org-modern t
  "Whether to enable org-modern modern interface."
  :type 'boolean
  :group 'mcg-org)

(defcustom mcg-org-modern-todo-faces
  '(("TODO" :inverse-video t :inherit org-todo)
    ("HOLD" :inverse-video t)
    ("WIP" :inverse-video t)
    ("WAIT" :inverse-video t)
    ("DONE" :inverse-video t :inherit org-done)
    ("CANCELLED" :inverse-video t))
  "Face definitions for org-modern TODO labels."
  :type 'sexp
  :group 'mcg-org)

(defun mcg--setup-org-modern ()
  "Set up org-modern."
  (with-eval-after-load 'org
    (when (and mcg-org-enable-org-modern
               (mcg-require-extension "org-modern" t))
      ;; Use unified bullets from mcg-org-bullets-alist
      (let ((headline-bullets (car mcg-org-bullets-alist))
            (item-bullets (cadr mcg-org-bullets-alist)))
        (setq org-modern-star headline-bullets
              org-modern-list item-bullets))
      (setq org-modern-table-vertical 1
            org-modern-table-horizontal 0.2
            org-modern-todo-faces mcg-org-modern-todo-faces
            org-modern-priority-faces
            '((?A :inverse-video t :inherit org-priority)
              (?B :inverse-video t :inherit org-priority)
              (?C :inverse-video t :inherit org-priority))
            org-modern-block-fringe nil
            org-modern-block-name
            '((t . t)
              ("src" "»" "«")
              ("example" "»–" "–«")
              ("quote" "❝" "❞")))

      (global-org-modern-mode 1)
      (mcg-log "Org modern configured"))))

(defun mcg/org-toggle-modern ()
  "Toggle org-modern mode."
  (interactive)
  (if (bound-and-true-p org-modern-mode)
      (org-modern-mode -1)
    (org-modern-mode 1))
  (message "Org-modern mode: %s"
           (if (bound-and-true-p org-modern-mode) "enabled" "disabled")))

(mcg--setup-org-modern)

(provide 'init-org-modern)
;;; init-org-modern.el ends here
