;;; init-org-extras.el --- Org Extras for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, calendar, keybindings

;;; Code:

(require 'core-lib)
(require 'init-org-agenda)  ; Load calendar configuration from agenda module

;;; Org Mode Keybindings

(defun mcg--setup-org-extras-keybindings ()
  "Setup Org extensions keybindings."
  (with-eval-after-load 'org
    (define-key org-mode-map (kbd "C-c n e") 'org-edit-src-code)
    (define-key org-mode-map (kbd "C-c n h") 'org-insert-heading)
    (define-key org-mode-map (kbd "C-c n s") 'org-insert-subheading))
  (mcg-log "Org extras keybindings configured"))

;;; Initialize

(mcg--setup-org-extras-keybindings)

(provide 'init-org-extras)
;;; init-org-extras.el ends here
