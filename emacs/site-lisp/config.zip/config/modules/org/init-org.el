;;; init-org.el --- Org Mode Configuration for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, outlines, planning
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Org mode configuration module for MCG Emacs, responsible for:
;; - Core org configuration
;; - Org extensions configuration
;; - Various org add-ons

;;; Code:

(require 'core-lib)
(require 'org)
(require 'ox)

(add-to-list 'load-path (expand-file-name "modules/org" mcg-emacs-dir))

;;; ============================================================
;;; Variables
;;; ============================================================

(defgroup mcg-org nil
  "Org mode configuration variables."
  :group 'org
  :prefix "mcg-org-")

(defcustom mcg-org-directory
  (expand-file-name "~/org")
  "Root directory for Org mode files."
  :type 'directory
  :group 'mcg-org)

(defcustom mcg-org-agenda-directory
  (expand-file-name "agenda" mcg-org-directory)
  "Org agenda files directory."
  :type 'directory
  :group 'mcg-org)

(defcustom mcg-org-notes-directory
  (expand-file-name "notes" mcg-org-directory)
  "Org notes files directory."
  :type 'directory
  :group 'mcg-org)

(defcustom mcg-org-default-notes-file
  (expand-file-name "notes.org" mcg-org-notes-directory)
  "Default notes file."
  :type 'file
  :group 'mcg-org)

(defcustom mcg-org-task-file
  (expand-file-name "tasks.org" mcg-org-agenda-directory)
  "Task file."
  :type 'file
  :group 'mcg-org)

(defcustom mcg-org-enable-pretty-symbols t
  "Whether to enable Org mode symbol beautification."
  :type 'boolean
  :group 'mcg-org)

(defcustom mcg-org-ellipsis " ..."
  "String shown after folded Org headlines and drawers.
Use an ASCII-safe default to avoid missing-glyph boxes on Windows fonts."
  :type 'string
  :group 'mcg-org)

(defcustom mcg-org-bullets-alist
  '(("◉" "○" "✸" "✿" "✤" "✜" "◆" "▶")
    ((43 . "◆")
     (45 . "▸")
     (42 . "•")))
  "Unified Org bullets configuration.
Structure: (headline-bullets item-bullet-alist)
where headline-bullets is a list of symbols for each level,
and item-bullet-alist is an alist mapping ASCII codes to bullet characters.

Used by org-modern for consistent appearance."
  :type '(list (repeat string) (repeat (cons integer string)))
  :group 'mcg-org)

(defcustom mcg-org-todo-keywords
  '((sequence
     "TODO(t)"
     "HOLD(h!)"
     "WIP(i!)"
     "WAIT(w!)"
     "|"
     "DONE(d!)"
     "CANCELLED(c@/!)")
    (sequence
     "REPORT(r)"
     "BUG(b)"
     "KNOWNCAUSE(k)"
     "|"
     "FIXED(f!)"))
  "Org TODO keyword workflow definitions."
  :type 'sexp
  :group 'mcg-org)

(defcustom mcg-org-todo-keyword-faces
  '(("TODO"       :foreground "#7c7c75" :weight bold)
    ("HOLD"       :foreground "#feb24c" :weight bold)
    ("WIP"        :foreground "#0098dd" :weight bold)
    ("WAIT"       :foreground "#9f7efe" :weight bold)
    ("DONE"       :foreground "#50a14f" :weight bold)
    ("CANCELLED"  :foreground "#ff6480" :weight bold))
  "Face definitions for Org TODO keywords."
  :type 'sexp
  :group 'mcg-org)

;; Blog-related variables are now in init-org-hugo.el
;; See: mcg-org-blog-directory, mcg-org-blog-development-file, etc.

;;; ============================================================
;;; Org Core Configuration
;;; ============================================================

(defun mcg-org-ensure-directory (dir)
  "Ensure directory DIR exists, create if not."
  (unless (file-exists-p dir)
    (make-directory dir t)
    (mcg-log "Created directory: %s" dir)))

(defun mcg-org-initialize-directories ()
  "Initialize all Org mode directories."
  (interactive)
  (mapc #'mcg-org-ensure-directory
        (list mcg-org-directory
              mcg-org-agenda-directory
              mcg-org-notes-directory))
  ;; Blog directory is initialized by init-org-hugo.el
  (mcg-log "Org directories initialized"))

(defun mcg--setup-org-core ()
  "Set up org mode core configuration."
  (setq org-ellipsis mcg-org-ellipsis
        org-tags-column 0
        org-log-into-drawer t
        org-pretty-entities t
        org-startup-indented t
        org-hide-leading-stars nil
        org-hide-emphasis-markers t
        org-image-actual-width '(800)
        org-startup-with-inline-images t
        org-indent-mode-turns-on-hiding-stars nil
        org-log-done 'time
        org-log-repeat 'time
        org-log-redeadline 'note
        org-log-reschedule 'note
        org-log-state-notes-insert-after-drawers nil)

  (setq org-todo-keywords mcg-org-todo-keywords)
  (setq org-todo-keyword-faces mcg-org-todo-keyword-faces)

  (custom-set-faces
   '(org-level-1 ((t (:height 1.15))))
   '(org-level-2 ((t (:height 1.13))))
   '(org-level-3 ((t (:height 1.11))))
   '(org-level-4 ((t (:height 1.09))))
   '(org-level-5 ((t (:height 1.07))))
   '(org-level-6 ((t (:height 1.05))))
   '(org-level-7 ((t (:height 1.03))))
   '(org-level-8 ((t (:height 1.01))))
   '(org-tag ((t (:inherit 'fixed-pitch))))
   '(org-date ((t (:inherit 'fixed-pitch))))
   '(org-todo ((t (:inherit 'fixed-pitch))))
   '(org-done ((t (:inherit 'fixed-pitch))))
   '(org-drawer ((t (:inherit 'fixed-pitch))))
   '(org-ellipsis ((t (:inherit 'fixed-pitch))))
   '(org-headline-done ((t (:inherit 'variable-pitch)))))

  (setq line-spacing 0.25
        org-list-demote-modify-bullet '(("+" . "-") ("-" . "+") ("*" . "+") ("1." . "a.")))

  (font-lock-add-keywords
   'org-mode
   '(("^ +\\([-*]\\) "
      (0 (prog1 () (compose-region (match-beginning 1) (match-end 1) "▻"))))))

  (setq prettify-symbols-alist
        (mapcan (lambda (x) (list x (cons (upcase (car x)) (cdr x))))
                '(("#+begin_src" . "↪")
                  ("#+end_src" . "↩")
                  (":PROPERTIES:" . "⥼")
                  (":END:" . "⥽"))))
  (setq prettify-symbols-unprettify-at-point t)

  (setq org-time-stamp-custom-formats
        '("<%Y-%m-%d %A %H:%M:%S>" . "<%Y-%m-%d %A %H:%M:%S>"))
  (setq system-time-locale "zh_CN.UTF-8")
  (setq org-display-custom-times t)

  (require 'ox-gfm nil t)
  (add-to-list 'org-export-backends 'md)

  (mcg-log "Org core configured"))

;;; ============================================================
;;; Load Org Extensions
;;; ============================================================

(require 'init-org-modern)
(require 'init-org-appear)
(require 'init-visual-fill-column)
(require 'init-org-download)
(require 'init-mixed-pitch)
(require 'init-ox-gfm)
(require 'init-org-numbering)
(require 'init-org-agenda)
(require 'init-org-babel)
(require 'init-org-capture)
(require 'init-org-hugo)      ; Hugo integration (combines easy-hugo, ox-hugo)
(require 'init-org-extras)

;;; Org Mode Hook

(defun mcg-org-mode-setup ()
  "Org mode initialization setup."
  (setq-local line-spacing 2)
  (visual-line-mode 1)

  (when mcg-org-enable-pretty-symbols
    (prettify-symbols-mode 1)))

;;; Commands

(defun mcg/org-open-notes ()
  "Open notes directory."
  (interactive)
  (find-file mcg-org-notes-directory))

(defun mcg/org-open-agenda-dir ()
  "Open agenda directory."
  (interactive)
  (find-file mcg-org-agenda-directory))

;;; ============================================================
;;; Initialize
;;; ============================================================

(mcg-org-initialize-directories)
(mcg--setup-org-core)
(add-hook 'org-mode-hook #'mcg-org-mode-setup)

(provide 'init-org)
;;; init-org.el ends here
