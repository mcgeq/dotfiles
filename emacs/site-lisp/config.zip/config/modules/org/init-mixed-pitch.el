;;; init-mixed-pitch.el --- Mixed Pitch for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: org, mixed-pitch

;;; Code:

(require 'core-lib)
(require 'init-font)  ; Load font utilities

;;; ============================================================
;;; Configuration
;;; ============================================================

(defcustom mcg-org-enable-mixed-pitch nil
  "Whether to enable mixed fonts (serif + monospace)."
  :type 'boolean
  :group 'mcg-org)

(defun mcg--setup-mixed-pitch ()
  "Set up mixed-pitch mode."
  (with-eval-after-load 'org
    (when (and mcg-org-enable-mixed-pitch
               (mcg-require-extension "mixed-pitch" t))
      (when (display-graphic-p)
        (let ((mono-font (or (mcg-get-monospace-font) "monospace"))
              (serif-font (mcg-get-serif-font)))
          (custom-set-faces
           `(default ((t (:font ,mono-font))))
           `(fixed-pitch ((t (:font ,mono-font :height 1.0))))
           `(variable-pitch ((t (:font ,serif-font :height 1.0)))))))
      (mcg-log "Mixed pitch configured"))))

(mcg--setup-mixed-pitch)

(provide 'init-mixed-pitch)
;;; init-mixed-pitch.el ends here
