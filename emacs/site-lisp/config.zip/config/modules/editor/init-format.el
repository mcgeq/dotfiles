;;; init-format.el --- Unified formatting commands for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: tools, format, convenience
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Provides one formatting command for daily development:
;; - prefer lsp-bridge when an LSP server is active
;; - fall back to language-specific formatter functions
;; - optionally format on save for selected major modes
;;
;;; Code:

(require 'core-lib)
(require 'cl-lib)
(require 'json)
(require 'subr-x)

(defcustom mcg-format-on-save nil
  "Whether `mcg-format-buffer' should run before saving supported buffers."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-format-on-save-modes
  '(python-mode python-ts-mode
    zig-mode zig-ts-mode
    web-mode html-mode css-mode css-ts-mode scss-mode less-css-mode
    js-mode js-ts-mode js-jsx-mode typescript-mode typescript-ts-mode tsx-ts-mode
    json-mode json-ts-mode yaml-mode yaml-ts-mode)
  "Major modes where `mcg-format-on-save' is allowed."
  :type '(repeat symbol)
  :group 'mcg)

(defcustom mcg-format-prefer-lsp t
  "Whether to try lsp-bridge formatting before local formatter functions."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-format-command-alist
  '((python-mode . mcg-format-with-external-command)
    (python-ts-mode . mcg-format-with-external-command)
    (zig-mode . mcg-format-zig-buffer)
    (zig-ts-mode . mcg-format-zig-buffer)
    (web-mode . mcg-format-with-external-command)
    (html-mode . mcg-format-with-external-command)
    (css-mode . mcg-format-with-external-command)
    (css-ts-mode . mcg-format-with-external-command)
    (scss-mode . mcg-format-with-external-command)
    (less-css-mode . mcg-format-with-external-command)
    (js-mode . mcg-format-with-external-command)
    (js-ts-mode . mcg-format-with-external-command)
    (js-jsx-mode . mcg-format-with-external-command)
    (typescript-mode . mcg-format-with-external-command)
    (typescript-ts-mode . mcg-format-with-external-command)
    (tsx-ts-mode . mcg-format-with-external-command)
    (json-mode . mcg-format-with-external-command)
    (json-ts-mode . mcg-format-with-external-command)
    (yaml-mode . mcg-format-with-external-command)
    (yaml-ts-mode . mcg-format-with-external-command))
  "Alist mapping major modes to formatter functions."
  :type '(alist :key-type symbol :value-type function)
  :group 'mcg)

(defvar mcg-format-web-modes
  '(web-mode html-mode css-mode css-ts-mode scss-mode less-css-mode
    js-mode js-ts-mode js-jsx-mode typescript-mode typescript-ts-mode tsx-ts-mode
    json-mode json-ts-mode yaml-mode yaml-ts-mode)
  "Major modes that use project-aware Web formatter detection.")

(defcustom mcg-format-external-command-alist
  '((python-mode . mcg-python-format-candidates)
    (python-ts-mode . mcg-python-format-candidates)
    (zig-mode . (("zig" "fmt")))
    (zig-ts-mode . (("zig" "fmt")))
    (web-mode . mcg-format--web-external-candidates)
    (html-mode . mcg-format--web-external-candidates)
    (css-mode . mcg-format--web-external-candidates)
    (css-ts-mode . mcg-format--web-external-candidates)
    (scss-mode . mcg-format--web-external-candidates)
    (less-css-mode . mcg-format--web-external-candidates)
    (js-mode . mcg-format--web-external-candidates)
    (js-ts-mode . mcg-format--web-external-candidates)
    (js-jsx-mode . mcg-format--web-external-candidates)
    (typescript-mode . mcg-format--web-external-candidates)
    (typescript-ts-mode . mcg-format--web-external-candidates)
    (tsx-ts-mode . mcg-format--web-external-candidates)
    (json-mode . mcg-format--web-external-candidates)
    (json-ts-mode . mcg-format--web-external-candidates)
    (yaml-mode . mcg-format--web-external-candidates)
    (yaml-ts-mode . mcg-format--web-external-candidates))
  "External formatter command candidates for each major mode.
Each value is either a list of command candidates or a function returning one.
Each candidate is a list whose car is the executable and cdr is the fixed args."
  :type '(alist :key-type symbol :value-type sexp)
  :group 'mcg)

(defvar-local mcg-format--inhibit-on-save nil
  "Non-nil means skip format-on-save in the current buffer.")

(defun mcg-format--supported-mode-p ()
  "Return non-nil when current `major-mode' supports format-on-save."
  (memq major-mode mcg-format-on-save-modes))

(defun mcg-format--lsp-available-p ()
  "Return non-nil when lsp-bridge can format the current buffer."
  (and mcg-format-prefer-lsp
       (bound-and-true-p lsp-bridge-mode)
       (fboundp 'lsp-bridge-has-lsp-server-p)
       (lsp-bridge-has-lsp-server-p)
       (fboundp 'lsp-bridge-code-format)))

(defun mcg-format--command-for-mode ()
  "Return formatter function for current `major-mode'."
  (cdr (assq major-mode mcg-format-command-alist)))

(defun mcg-format--project-root ()
  "Return current project root for formatter detection."
  (if (fboundp 'mcg-project-root-or-default)
      (mcg-project-root-or-default)
    default-directory))

(defun mcg-format--root-file (root file)
  "Return FILE expanded under ROOT."
  (expand-file-name file root))

(defun mcg-format--root-has-file-p (root file)
  "Return non-nil when ROOT contains FILE."
  (file-exists-p (mcg-format--root-file root file)))

(defun mcg-format--root-has-any-file-p (root files)
  "Return non-nil when ROOT contains any file in FILES."
  (cl-some (lambda (file)
             (mcg-format--root-has-file-p root file))
           files))

(defun mcg-format--read-package-json (root)
  "Read package.json from ROOT as an alist, or nil when unavailable."
  (let ((file (mcg-format--root-file root "package.json")))
    (when (file-exists-p file)
      (condition-case nil
          (let ((json-object-type 'alist)
                (json-array-type 'list)
                (json-key-type 'symbol))
            (json-read-file file))
        (error nil)))))

(defun mcg-format--package-section (package section)
  "Return SECTION from PACKAGE alist."
  (cdr (assoc section package)))

(defun mcg-format--package-has-key-p (package section key)
  "Return non-nil when PACKAGE SECTION contains KEY."
  (assoc-string key (mcg-format--package-section package section) t))

(defun mcg-format--package-has-any-key-p (package sections key)
  "Return non-nil when PACKAGE has KEY in any of SECTIONS."
  (cl-some (lambda (section)
             (mcg-format--package-has-key-p package section key))
           sections))

(defun mcg-format--file-contains-p (file regexp)
  "Return non-nil when FILE contains REGEXP."
  (when (file-exists-p file)
    (with-temp-buffer
      (insert-file-contents file)
      (goto-char (point-min))
      (re-search-forward regexp nil t))))

(defun mcg-format--root-file-contains-any-p (root files regexp)
  "Return non-nil when any file in FILES under ROOT contains REGEXP."
  (cl-some (lambda (file)
             (mcg-format--file-contains-p
              (mcg-format--root-file root file)
              regexp))
           files))

(defun mcg-format--web-eslint-config-files ()
  "Return known ESLint config file names."
  '("eslint.config.js"
    "eslint.config.mjs"
    "eslint.config.cjs"
    "eslint.config.ts"
    ".eslintrc"
    ".eslintrc.js"
    ".eslintrc.cjs"
    ".eslintrc.json"
    ".eslintrc.yaml"
    ".eslintrc.yml"))

(defun mcg-format--web-prettier-config-files ()
  "Return known Prettier config file names."
  '(".prettierrc"
    ".prettierrc.json"
    ".prettierrc.json5"
    ".prettierrc.yaml"
    ".prettierrc.yml"
    ".prettierrc.js"
    ".prettierrc.cjs"
    ".prettierrc.mjs"
    "prettier.config.js"
    "prettier.config.cjs"
    "prettier.config.mjs"))

(defun mcg-format--web-project-has-antfu-eslint-p (&optional root)
  "Return non-nil when ROOT declares Antfu ESLint configuration."
  (let* ((root (file-name-as-directory (or root (mcg-format--project-root))))
         (package (mcg-format--read-package-json root)))
    (or (and package
             (mcg-format--package-has-any-key-p
              package
              '(dependencies devDependencies optionalDependencies peerDependencies)
              "@antfu/eslint-config"))
        (mcg-format--root-file-contains-any-p
         root
         (mcg-format--web-eslint-config-files)
         "@antfu/eslint-config"))))

(defun mcg-format--web-project-has-eslint-p (&optional root)
  "Return non-nil when ROOT declares ESLint formatting/linting."
  (let* ((root (file-name-as-directory (or root (mcg-format--project-root))))
         (package (mcg-format--read-package-json root)))
    (or (mcg-format--web-project-has-antfu-eslint-p root)
        (mcg-format--root-has-any-file-p
         root
         (mcg-format--web-eslint-config-files))
        (and package
             (or (assoc 'eslintConfig package)
                 (mcg-format--package-has-any-key-p
                  package
                  '(dependencies devDependencies optionalDependencies peerDependencies)
                  "eslint"))))))

(defun mcg-format--web-project-has-prettier-p (&optional root)
  "Return non-nil when ROOT explicitly declares Prettier."
  (let* ((root (file-name-as-directory (or root (mcg-format--project-root))))
         (package (mcg-format--read-package-json root)))
    (or (mcg-format--root-has-any-file-p
         root
         (mcg-format--web-prettier-config-files))
        (and package
             (or (assoc 'prettier package)
                 (mcg-format--package-has-any-key-p
                  package
                  '(dependencies devDependencies optionalDependencies peerDependencies)
                  "prettier"))))))

(defun mcg-format--node-tool-command (root tool args)
  "Return command candidate for TOOL with ARGS in ROOT."
  (cond
   ((or (mcg-format--root-has-file-p root "pnpm-lock.yaml")
        (mcg-format--root-has-file-p root "pnpm-workspace.yaml"))
    (append (list "pnpm" "exec" tool) args))
   ((or (mcg-format--root-has-file-p root "bun.lock")
        (mcg-format--root-has-file-p root "bun.lockb"))
    (append (list "bun" "x" tool) args))
   ((mcg-format--root-has-file-p root "package-lock.json")
    (append (list "npm" "exec" "--" tool) args))
   (t
    (cons tool args))))

(defun mcg-format--web-external-candidates ()
  "Return project-aware Web formatter candidates.
ESLint is preferred when the project declares Antfu or any ESLint config.
Prettier is only used when the project explicitly declares Prettier."
  (let ((root (file-name-as-directory (mcg-format--project-root))))
    (cond
     ((mcg-format--web-project-has-eslint-p root)
      (list (mcg-format--node-tool-command root "eslint" '("--fix"))))
     ((mcg-format--web-project-has-prettier-p root)
      (list (mcg-format--node-tool-command root "prettier" '("--write"))))
     (t nil))))

(defun mcg-format--external-candidates ()
  "Return external formatter candidates for current `major-mode'."
  (let ((entry (cdr (assq major-mode mcg-format-external-command-alist))))
    (cond
     ((functionp entry)
      (funcall entry))
     ((and (symbolp entry) (fboundp entry))
      (funcall entry))
     (t entry))))

(defun mcg-format--select-external-command ()
  "Return the first available external formatter command for current buffer."
  (cl-find-if (lambda (candidate)
                (and (consp candidate)
                     (executable-find (car candidate))))
              (mcg-format--external-candidates)))

(defun mcg-format--call-process (program args file)
  "Run PROGRAM with ARGS against FILE and return non-nil on success."
  (let ((buffer (get-buffer-create "*MCG Format*")))
    (with-current-buffer buffer
      (erase-buffer))
    (let ((exit-code
           (apply #'call-process program nil buffer nil
                  (append args (list file)))))
      (if (zerop exit-code)
          t
        (display-buffer buffer)
        (mcg-log-warning "Formatter failed: %s %s" program (string-join args " "))
        nil))))

;;;###autoload
(defun mcg-format-zig-buffer ()
  "Format current Zig buffer with zig-mode or external `zig fmt'."
  (interactive)
  (if (fboundp 'zig-format-buffer)
      (call-interactively #'zig-format-buffer)
    (mcg-format-with-external-command)))

;;;###autoload
(defun mcg-format-with-external-command ()
  "Format current file with the first available external formatter."
  (interactive)
  (unless buffer-file-name
    (user-error "Current buffer is not visiting a file"))
  (let ((candidate (mcg-format--select-external-command)))
    (unless candidate
      (user-error "No formatter found for %s" major-mode))
    (save-buffer)
    (when (mcg-format--call-process (car candidate) (cdr candidate) buffer-file-name)
      (revert-buffer :ignore-auto :noconfirm)
      (mcg-log "Formatted %s with %s" buffer-file-name (car candidate))
      t)))

;;;###autoload
(defun mcg-format-buffer ()
  "Format current buffer using the best available formatter."
  (interactive)
  (cond
   ((mcg-format--lsp-available-p)
    (call-interactively #'lsp-bridge-code-format)
    t)
   ((let ((formatter (mcg-format--command-for-mode)))
      (when (and formatter (fboundp formatter))
        (call-interactively formatter)
        t)))
   (t
    (user-error "No formatter available for %s" major-mode))))

(defun mcg-format-buffer-maybe ()
  "Format current buffer before saving when enabled and supported."
  (when (and mcg-format-on-save
             (not mcg-format--inhibit-on-save)
             (mcg-format--supported-mode-p)
             (not buffer-read-only))
    (let ((mcg-format--inhibit-on-save t))
      (ignore-errors
        (mcg-format-buffer)))))

;;;###autoload
(defun mcg-format-toggle-on-save ()
  "Toggle global MCG format-on-save."
  (interactive)
  (setq mcg-format-on-save (not mcg-format-on-save))
  (message "MCG format-on-save %s" (if mcg-format-on-save "enabled" "disabled")))

(add-hook 'before-save-hook #'mcg-format-buffer-maybe)

(mcg-bind-key "C-c r f" #'mcg-format-buffer "editor/format")
(mcg-bind-key "C-c r F" #'mcg-format-toggle-on-save "editor/format")

(mcg-log "format module configured")

(provide 'init-format)
;;; init-format.el ends here
