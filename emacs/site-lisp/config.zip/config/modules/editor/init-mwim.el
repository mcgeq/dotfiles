;;; init-mwim.el --- MWIM for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: editor, navigation, mwim
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; MWIM (Move Where I Mean) provides intelligent movement commands
;; that switch between various line positions like code beginning,
;; line beginning, or comment.

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; MWIM Configuration
;;; ============================================================

(defun mcg-mwim-setup ()
  "Setup mwim package."
  ;; Bind C-a to mwim-beginning: toggles between code-beginning and line-beginning
  (mcg-bind-key "C-a" #'mwim-beginning "editor/mwim")
  
  ;; Bind C-e to mwim-end: toggles between code-end and line-end
  (mcg-bind-key "C-e" #'mwim-end "editor/mwim")
  
  ;; Optional: bind home/end keys
  (mcg-bind-key "<home>" #'mwim-beginning-of-line-or-code "editor/mwim")
  (mcg-bind-key "<end>" #'mwim-end-of-line-or-code "editor/mwim")
  
  (mcg-log "Configured mwim"))

;;; ============================================================
;;; Initialize
;;; ============================================================

(autoload 'mwim-beginning "mwim" nil t)
(autoload 'mwim-end "mwim" nil t)
(autoload 'mwim-beginning-of-line-or-code "mwim" nil t)
(autoload 'mwim-end-of-line-or-code "mwim" nil t)

(mcg-mwim-setup)

(provide 'init-mwim)
;;; init-mwim.el ends here
