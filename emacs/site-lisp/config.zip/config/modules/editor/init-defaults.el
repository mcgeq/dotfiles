;;; init-defaults.el --- Editor Defaults for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: editor, defaults, builtin
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Editor defaults module for MCG Emacs configuration, responsible for:
;; - savehist history records
;; - backup and auto-save files
;; - saveplace position memory
;; - whitespace character display
;; - autorevert auto refresh
;; - hideshow code folding
;; - newcomment commenting
;; - delete-selection selection deletion
;; - line number display

;;; Code:

(require 'core-lib)
(require 'cl-lib)
(require 'savehist)
(require 'saveplace)
(require 'whitespace)
(require 'autorevert)
(require 'hideshow)
(require 'newcomment)
(require 'delsel)
(require 'display-line-numbers)

;;; ============================================================
;;; Basic Settings
;;; ============================================================

;; Windows system time settings
(when (eq system-type 'windows-nt)
  (setq system-time-locale "C"))

;; UTF-8 encoding settings
(unless (memq system-type '(cygwin windows-nt ms-dos))
  (set-selection-coding-system 'utf-8))
(prefer-coding-system 'utf-8)
(set-default-coding-systems 'utf-8)
(set-terminal-coding-system 'utf-8)
(set-keyboard-coding-system 'utf-8)
(set-buffer-file-coding-system 'utf-8)

;; Performance optimization
(setq bidi-inhibit-bpa t)
(setq-default bidi-paragraph-direction 'left-to-right)
(setq process-adaptive-read-buffering nil)
(setq read-process-output-max (* 1024 1024))

;; Basic UI settings
(setq use-short-answers t)
(blink-cursor-mode -1)
(transient-mark-mode 1)
(global-subword-mode 1)
(setq use-dialog-box nil)
(setq initial-scratch-message
      (concat ";; Happy hacking, "
              (capitalize user-login-name)
              " - Emacs ❤ you!\n\n"))

;; Editing settings
(setq-default comment-style 'indent)
(setq ring-bell-function 'ignore)
(setq-default major-mode 'text-mode)
(setq mouse-yank-at-point t)
(setq select-enable-clipboard t)
(setq split-width-threshold nil)
(setq inhibit-compacting-font-caches t)
(setq confirm-kill-processes nil)
(setq word-wrap-by-category t)
(setq column-number-mode t)
(setq completion-auto-select nil)
(setq ad-redefinition-action 'accept)
(setq switch-to-buffer-in-dedicated-window 'pop)
(setq switch-to-buffer-obey-display-actions t)

;; Smooth scrolling
(setq scroll-step 1)
(setq scroll-conservatively 10000)

;; Cursor style
(setq-default cursor-type '(bar . 5))

;; Auto line wrap
(global-visual-line-mode t)

;; Bracket matching
(setq electric-pair-inhibit-predicate 'electric-pair-conservative-inhibit)
(electric-pair-mode 1)

;;; ============================================================
;;; Variables
;;; ============================================================

(defvar mcg-editor-history-length 1000
  "Maximum number of history entries to save.")

(defvar mcg-editor-savehist-interval 300
  "Savehist auto-save interval in seconds.")

(defvar mcg-editor-line-numbers-type 'relative
  "Line number display type.
Options: t (absolute), 'relative (relative), 'visual (visual), nil (disabled)")

(defvar mcg-editor-default-fill-column 100
  "Default fill column for line wrapping.")

(defvar mcg-editor-indent-tabs-modes
  '(makefile-gmake-mode makefile-mode)
  "List of modes that use tab indentation.")

;;; ============================================================
;;; Warning Suppression
;;; ============================================================

(setq warning-suppress-types
      (append '((lexical-binding)
                (files))
              warning-suppress-types))

;;; ============================================================
;;; Savehist Configuration
;;; ============================================================

(defun mcg-editor-setup-savehist ()
  "Setup savehist history records."
  (unless mcg-cache-dir
    (mcg-init-paths))
  (make-directory mcg-cache-dir t)
  (setq enable-recursive-minibuffers t)
  (setq history-length mcg-editor-history-length)
  (setq savehist-file (expand-file-name "savehist.el" mcg-cache-dir))
  (setq savehist-additional-variables
        '(mark-ring
          global-mark-ring
          search-ring
          regexp-search-ring
          extended-command-history))
  (setq savehist-autosave-interval mcg-editor-savehist-interval)
  (savehist-mode 1)
  (mcg-log "Enabled savehist-mode"))

(defun mcg-editor-clean-savehist-kill-ring ()
  "Strip text properties from string entries in `kill-ring'."
  (setq kill-ring
        (mapcar #'substring-no-properties
                (cl-remove-if-not #'stringp kill-ring))))

(add-hook 'savehist-save-hook #'mcg-editor-clean-savehist-kill-ring)

(defun mcg-editor-setup-backups ()
  "Store backup and auto-save files under `mcg-cache-dir'."
  (unless mcg-cache-dir
    (mcg-init-paths))
  (let ((backup-dir (expand-file-name "backups/" mcg-cache-dir))
        (auto-save-dir (expand-file-name "auto-save/" mcg-cache-dir)))
    (make-directory backup-dir t)
    (make-directory auto-save-dir t)
    (setq backup-directory-alist `((".*" . ,backup-dir)))
    (setq auto-save-file-name-transforms `((".*" ,auto-save-dir t)))
    (setq auto-save-list-file-prefix (expand-file-name ".saves-" auto-save-dir))
    (setq create-lockfiles nil)
    (mcg-log "Configured backup and auto-save directories")))

;;; ============================================================
;;; Saveplace Configuration
;;; ============================================================

(defun mcg-editor-setup-saveplace ()
  "Setup saveplace position memory."
  (unless mcg-cache-dir
    (mcg-init-paths))
  (make-directory mcg-cache-dir t)
  (setq save-place-file (expand-file-name "places.el" mcg-cache-dir))
  (save-place-mode 1)
  (mcg-log "Enabled save-place-mode"))

;;; ============================================================
;;; Whitespace Configuration
;;; ============================================================

(defun mcg-editor-setup-whitespace ()
  "Setup whitespace character display."
  ;; Custom faces
  (face-spec-set 'whitespace-tab
                 '((t :background unspecified)))
  (face-spec-set 'whitespace-line
                 '((((background light))
                    :background "#d8d8d8" :foreground unspecified
                    :underline t :weight unspecified)
                   (t
                    :background "#404040" :foreground unspecified
                    :underline t :weight unspecified)))
  (face-spec-set 'whitespace-space-before-tab
                 '((((background light))
                    :background "#d8d8d8" :foreground "#de4da1")
                   (t
                    :inherit warning
                    :background "#404040" :foreground "#ee6aa7")))
  
  ;; Configure display style
  (setq whitespace-line-column nil)
  (setq whitespace-style
        '(face
          empty
          lines-tail
          space-before-tab
          trailing
          tabs
          tab-mark))
  
  (global-whitespace-mode 1)
  (mcg-log "Enabled global-whitespace-mode"))

;;; ============================================================
;;; Autorevert Configuration
;;; ============================================================

(defun mcg-editor-setup-autorevert ()
  "Setup autorevert auto refresh."
  (global-auto-revert-mode 1)
  (mcg-log "Enabled global-auto-revert-mode"))

;;; ============================================================
;;; Hideshow Configuration
;;; ============================================================

(defconst mcg-editor-hideshow-folded-face
  '((t (:inherit 'font-lock-comment-face :box t)))
  "Face for code folding indicator.")

(defun mcg-editor--hideshow-overlay-fn (ov)
  "Custom hideshow folding display.
OV is the overlay object."
  (when (eq 'code (overlay-get ov 'hs))
    (let* ((nlines (count-lines (overlay-start ov) (overlay-end ov)))
           (info (format " ... #%d " nlines)))
      (overlay-put ov 'display
                   (propertize info 'face mcg-editor-hideshow-folded-face)))))

(defun mcg-editor-setup-hideshow ()
  "Setup hideshow code folding."
  (setq hs-set-up-overlay 'mcg-editor--hideshow-overlay-fn)
  (add-hook 'prog-mode-hook #'hs-minor-mode)
  (mcg-log "Configured hideshow for prog-mode"))

;;; ============================================================
;;; Newcomment Configuration
;;; ============================================================

(defun mcg/comment-or-uncomment ()
  "Toggle comment state of selected region or current line."
  (interactive)
  (if (region-active-p)
      (comment-or-uncomment-region (region-beginning) (region-end))
    (if (save-excursion
          (beginning-of-line)
          (looking-at "\\s-*$"))
        (call-interactively 'comment-dwim)
      (comment-or-uncomment-region (line-beginning-position)
                                   (line-end-position)))))

(defun mcg-editor-setup-newcomment ()
  "Setup newcomment commenting functionality."
  (global-set-key [remap comment-dwim] #'mcg/comment-or-uncomment)
  (setq comment-auto-fill-only-comments t)
  (mcg-log "Configured newcomment"))

;;; ============================================================
;;; Delete Selection Configuration
;;; ============================================================

(defun mcg-editor-setup-delete-selection ()
  "Setup delete-selection mode."
  (delete-selection-mode 1)
  (mcg-log "Enabled delete-selection-mode"))

;;; ============================================================
;;; Indent Tabs Configuration
;;; ============================================================

(defun mcg-editor--toggle-indent-tabs-mode ()
  "Toggle indent-tabs-mode based on major-mode."
  (setq indent-tabs-mode
        (if (member major-mode mcg-editor-indent-tabs-modes)
            t
          nil)))

(defun mcg-editor-setup-indent-tabs ()
  "Setup indent-tabs-mode auto-toggle."
  (add-hook 'after-change-major-mode-hook #'mcg-editor--toggle-indent-tabs-mode)
  (mcg-log "Configured indent-tabs-mode auto-toggle"))

;;; ============================================================
;;; Language Indent Configuration
;;; ============================================================

;; Default indentation settings
(setq-default indent-tabs-mode nil)
(setq-default tab-width 4)
(setq-default python-indent-offset 4)
(setq-default python-indent-guess-indent-offset nil)

;; 确保常用缩进变量已定义（避免 lsp-bridge 等包在 json-mode 等模式下报错）
(unless (boundp 'js-indent-level)
  (defvar js-indent-level 2 "JavaScript 缩进级别。"))

(defun mcg-editor--adjust-languages-indent (n)
  "Set indentation for various languages to N spaces."
  ;; C/C++
  (setq-local c-basic-offset n)
  ;; JavaScript (only if the variable exists)
  (when (boundp 'javascript-indent-level)
    (setq-local javascript-indent-level n))
  (when (boundp 'js-indent-level)
    (setq-local js-indent-level n))
  (when (boundp 'js2-basic-offset)
    (setq-local js2-basic-offset n))
  (when (boundp 'coffee-tab-width)
    (setq-local coffee-tab-width n))
  ;; Web mode
  (when (boundp 'web-mode-attr-indent-offset)
    (setq-local web-mode-attr-indent-offset n))
  (when (boundp 'web-mode-attr-value-indent-offset)
    (setq-local web-mode-attr-value-indent-offset n))
  (when (boundp 'web-mode-code-indent-offset)
    (setq-local web-mode-code-indent-offset n))
  (when (boundp 'web-mode-css-indent-offset)
    (setq-local web-mode-css-indent-offset n))
  (when (boundp 'web-mode-markup-indent-offset)
    (setq-local web-mode-markup-indent-offset n))
  (when (boundp 'web-mode-sql-indent-offset)
    (setq-local web-mode-sql-indent-offset n))
  ;; CSS
  (when (boundp 'css-indent-offset)
    (setq-local css-indent-offset n))
  ;; Python
  (when (boundp 'python-indent-offset)
    (setq-local python-indent-offset n))
  (when (boundp 'python-indent-guess-indent-offset)
    (setq-local python-indent-guess-indent-offset nil))
  ;; TypeScript
  (when (boundp 'typescript-indent-level)
    (setq-local typescript-indent-level n)))

(defun mcg-editor-setup-language-indent ()
  "Setup language-specific indentation."
  ;; Languages with 4-space indentation
  (dolist (hook '(c-mode-hook c++-mode-hook java-mode-hook
                  haskell-mode-hook asm-mode-hook sh-mode-hook
                  ruby-mode-hook rust-mode-hook python-mode-hook
                  python-ts-mode-hook))
    (add-hook hook (lambda ()
                     (setq indent-tabs-mode nil)
                     (mcg-editor--adjust-languages-indent 4))))
  ;; Languages with 2-space indentation
  (dolist (hook '(web-mode-hook js-mode-hook js-ts-mode-hook
                  typescript-ts-mode-hook tsx-ts-mode-hook
                  json-mode-hook css-mode-hook scss-mode-hook))
    (add-hook hook (lambda ()
                     (setq indent-tabs-mode nil)
                     (mcg-editor--adjust-languages-indent 2))))
  (mcg-log "Configured language-specific indentation"))

;;; ============================================================
;;; Line Numbers Configuration
;;; ============================================================

(defun mcg-editor-setup-line-numbers ()
  "Setup line number display."
  (setq display-line-numbers-type mcg-editor-line-numbers-type)
  (setq display-line-numbers-width-start t)
  ;; Enable line numbers in specific modes
  (dolist (hook '(prog-mode-hook yaml-mode-hook conf-mode-hook markdown-mode-hook))
    (add-hook hook #'display-line-numbers-mode))
  (mcg-log "Configured line numbers display"))

;;; ============================================================
;;; Auto Fill Configuration
;;; ============================================================

(defun mcg-editor-setup-auto-fill ()
  "Setup auto line wrap."
  (setq-default fill-column mcg-editor-default-fill-column)
  (dolist (hook '(text-mode-hook message-mode-hook))
    (add-hook hook #'auto-fill-mode))
  (mcg-log "Configured auto-fill"))

;;; ============================================================
;;; Smart Kill Configuration
;;; ============================================================

(defun mcg/kill-dwim ()
  "Kill region or next sexp, fallback to line.
If region is active, kill region.
Otherwise try `kill-sexp' first; if it fails, kill line.

In Org mode, keep default `C-k` behavior and use `C-M-k` for sexp kill."
  (interactive)
  (cond
   ((use-region-p)
    (kill-region (region-beginning) (region-end)))
   (t
    (condition-case _
        (kill-sexp 1)
      (error (kill-line 1))))))

(defvar mcg-smart-kill-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-k") #'mcg/kill-dwim)
    (define-key map [remap kill-line] #'mcg/kill-dwim)
    (define-key map [remap kill-visual-line] #'mcg/kill-dwim)
    map)
  "Keymap for `mcg-smart-kill-mode'.")

(defvar mcg-smart-kill-emulation-map-alist
  `((mcg-smart-kill-mode . ,mcg-smart-kill-mode-map))
  "Emulation map alist for `mcg-smart-kill-mode'.")

(add-to-list 'emulation-mode-map-alists 'mcg-smart-kill-emulation-map-alist)

(define-minor-mode mcg-smart-kill-mode
  "Minor mode for structural-first `C-k'."
  :init-value nil
  :lighter nil
  :keymap mcg-smart-kill-mode-map)

(defun mcg-editor--setup-smart-kill-keybindings ()
  "Setup smart kill keybindings for different major modes."
  ;; Programming and Markdown modes: use smart structural kill via minor mode.
  (add-hook 'prog-mode-hook #'mcg-smart-kill-mode)
  (add-hook 'markdown-mode-hook #'mcg-smart-kill-mode)

  ;; Org: keep default C-k behavior, ensure C-M-k is structural kill.
  (add-hook 'org-mode-hook
            (lambda ()
              (local-set-key (kbd "C-M-k") #'kill-sexp)))

  (mcg-log "Configured smart kill keybindings"))

;;; ============================================================
;;; Commands
;;; ============================================================

(defun mcg/toggle-line-numbers ()
  "Toggle line number display."
  (interactive)
  (if display-line-numbers-mode
      (display-line-numbers-mode -1)
    (display-line-numbers-mode 1)))

(defun mcg/cycle-line-numbers-type ()
  "Cycle line number type: absolute -> relative -> visual -> disabled."
  (interactive)
  (setq display-line-numbers-type
        (pcase display-line-numbers-type
          ('nil t)
          ('t 'relative)
          ('relative 'visual)
          ('visual nil)))
  (when display-line-numbers-mode
    (display-line-numbers-mode -1)
    (display-line-numbers-mode 1))
  (message "Line numbers: %s"
           (or display-line-numbers-type "disabled")))

(defun mcg/toggle-whitespace ()
  "Toggle whitespace character display."
  (interactive)
  (if global-whitespace-mode
      (global-whitespace-mode -1)
    (global-whitespace-mode 1))
   (message "Whitespace mode: %s"
            (if global-whitespace-mode "enabled" "disabled")))

;;; ============================================================
;;; Initialize
;;; ============================================================

;; Setup built-in features
(mcg-editor-setup-savehist)
(mcg-editor-setup-backups)
(mcg-editor-setup-saveplace)
(mcg-editor-setup-whitespace)
(mcg-editor-setup-autorevert)
(mcg-editor-setup-hideshow)
(mcg-editor-setup-newcomment)
(mcg-editor-setup-delete-selection)
(mcg-editor-setup-indent-tabs)
(mcg-editor-setup-language-indent)
(mcg-editor-setup-line-numbers)
(mcg-editor-setup-auto-fill)
(mcg-editor--setup-smart-kill-keybindings)

(provide 'init-defaults)
;;; init-defaults.el ends here
