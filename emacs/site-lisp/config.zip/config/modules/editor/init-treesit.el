;;; init-treesit.el --- Tree-sitter Configuration for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: tree-sitter, syntax, highlighting
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Tree-sitter configuration module for MCG Emacs, using treesit-auto for:
;; - automatic language grammar installation
;; - major-mode remapping
;; - file type associations

;;; Code:

(require 'core-lib)
(require 'seq)
(require 'treesit)

;;; ============================================================
;;; Prevent typescript-mode Package Loading
;;; ============================================================

(with-eval-after-load 'typescript-mode
  (message "Warning: typescript-mode package loaded. This may cause hierarchy conflicts with typescript-ts-mode."))

(defun mcg--remove-typescript-mode-from-auto-mode-alist ()
  "Remove typescript-mode entries from auto-mode-alist."
  (setq auto-mode-alist
        (seq-remove (lambda (pair)
                      (eq (cdr pair) 'typescript-mode))
                    auto-mode-alist)))

(add-hook 'after-init-hook #'mcg--remove-typescript-mode-from-auto-mode-alist)

;;; ============================================================
;;; Load treesit-auto
;;; ============================================================

(mcg-require-extension 'treesit-auto t)

;;; ============================================================
;;; Extra Language Sources
;;; ============================================================

(add-to-list 'treesit-language-source-alist
             '(mojo . ("https://github.com/HerringtonDarkholme/tree-sitter-mojo")))

(add-to-list 'treesit-language-source-alist
             '(markdown-inline . ("https://github.com/tree-sitter-grammars/tree-sitter-markdown"
                                  "split_parser" "tree-sitter-markdown-inline/src")))

(add-to-list 'treesit-language-source-alist
             '(jsdoc . ("https://github.com/tree-sitter/tree-sitter-jsdoc")))

;;; ============================================================
;;; Initialize
;;; ============================================================

;; Set tree-sitter grammar install directory
(setq treesit-extra-load-path
      (list (expand-file-name "tree-sitter" user-emacs-directory)))

;; Enable treesit-auto
(treesit-auto-add-to-auto-mode-alist 'all)
(global-treesit-auto-mode)

;; Syntax highlighting level (1-4)
(setq treesit-font-lock-level 4)

;;; ============================================================
;;; Commands
;;; ============================================================

(defun mcg/treesit-explore ()
  "Open tree-sitter syntax tree explorer for current buffer."
  (interactive)
  (if (treesit-parser-list)
      (treesit-explore-mode)
    (message "No tree-sitter parser active in this buffer")))

(provide 'init-treesit)
;;; init-treesit.el ends here
