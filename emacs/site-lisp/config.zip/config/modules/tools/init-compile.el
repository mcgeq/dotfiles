;;; init-compile.el --- Compile workflow for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: compile, build, test
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Provides project-aware wrappers around built-in compile.el.
;;
;;; Code:

(require 'core-lib)
(require 'compile)

(defcustom mcg-compile-save-buffers t
  "Whether MCG compile commands save modified buffers before running."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-compile-scroll-output t
  "Non-nil means compilation buffers scroll as output arrives."
  :type 'boolean
  :group 'mcg)

(defun mcg-compile--root-has-p (root file)
  "Return non-nil when ROOT contains FILE."
  (file-exists-p (expand-file-name file root)))

(defun mcg-compile--js-runner (root)
  "Return preferred JavaScript package manager for ROOT."
  (cond
   ((and (or (mcg-compile--root-has-p root "pnpm-lock.yaml")
             (mcg-compile--root-has-p root "pnpm-workspace.yaml"))
         (executable-find "pnpm"))
    "pnpm")
   ((and (or (mcg-compile--root-has-p root "bun.lock")
             (mcg-compile--root-has-p root "bun.lockb"))
         (executable-find "bun"))
    "bun")
   ((and (mcg-compile--root-has-p root "yarn.lock")
         (executable-find "yarn"))
    "yarn")
   (t "npm")))

(defun mcg-compile--js-command (root action)
  "Return JavaScript command for ROOT and ACTION."
  (let ((runner (mcg-compile--js-runner root)))
    (pcase (list runner action)
      (`("bun" build) "bun run build")
      (`("bun" test) "bun test")
      (`("bun" run) "bun run start")
      (`("npm" build) "npm run build")
      (`("npm" test) "npm test")
      (`("npm" run) "npm start")
      (`(,runner build) (format "%s build" runner))
      (`(,runner test) (format "%s test" runner))
      (`(,runner run) (format "%s start" runner)))))

(defun mcg-compile--python-command (root action)
  "Return Python command for ROOT and ACTION.
When the Python module is loaded, reuse its project-aware pytest detection."
  (pcase action
    ('build "python -m build")
    ((or 'test 'run)
     (if (fboundp 'mcg-python--pytest-command)
         (mcg-python--pytest-command (file-name-as-directory root))
       "python -m pytest"))))

(defun mcg-compile--zig-command (action)
  "Return Zig command for ACTION.
When the Zig module is loaded, reuse its build command helper."
  (if (fboundp 'mcg-zig-build-command)
      (mcg-zig-build-command action)
    (pcase action
      ('build "zig build")
      ('test "zig build test")
      ('run "zig build run"))))

(defun mcg-compile--guess-command (root action)
  "Guess a shell command for ROOT and ACTION."
  (cond
   ((mcg-compile--root-has-p root "build.zig")
    (mcg-compile--zig-command action))
   ((mcg-compile--root-has-p root "Cargo.toml")
    (pcase action
      ('build "cargo build")
      ('test "cargo test")
      ('run "cargo run")))
   ((mcg-compile--root-has-p root "go.mod")
    (pcase action
      ('build "go build ./...")
      ('test "go test ./...")
      ('run "go run .")))
   ((mcg-compile--root-has-p root "package.json")
    (mcg-compile--js-command root action))
   ((or (mcg-compile--root-has-p root "Makefile")
        (mcg-compile--root-has-p root "makefile"))
    (pcase action
      ('build "make")
      ('test "make test")
      ('run "make run")))
   ((mcg-compile--root-has-p root "pyproject.toml")
    (mcg-compile--python-command root action))))

(defun mcg-compile--read-command (prompt default)
  "Read a shell command with PROMPT and DEFAULT."
  (read-shell-command prompt default 'compile-history))

(defun mcg-compile--consult-compile-error-p ()
  "Return non-nil when `consult-compile-error' is available."
  (or (fboundp 'consult-compile-error)
      (require 'consult-compile nil t)))

(defun mcg-compile--run (command root)
  "Run compile COMMAND in ROOT."
  (when mcg-compile-save-buffers
    (save-some-buffers t))
  (let ((default-directory root)
        (compile-command command))
    (compile command)))

(defun mcg-compile--dispatch (action edit)
  "Run ACTION command.
When EDIT is non-nil, prompt before running the guessed command."
  (let* ((root (mcg-project-root-or-default))
         (guess (or (mcg-compile--guess-command root action)
                    compile-command))
         (command (if edit
                      (mcg-compile--read-command
                       (format "%s command: " (capitalize (symbol-name action)))
                       guess)
                    guess)))
    (mcg-compile--run command root)))

;;;###autoload
(defun mcg-compile ()
  "Run a compile command in the current project."
  (interactive)
  (let* ((root (mcg-project-root-or-default))
         (command (mcg-compile--read-command "Compile command: " compile-command)))
    (mcg-compile--run command root)))

;;;###autoload
(defun mcg-recompile ()
  "Re-run the last compilation."
  (interactive)
  (if (get-buffer "*compilation*")
      (recompile)
    (call-interactively #'mcg-compile)))

;;;###autoload
(defun mcg-compile-errors ()
  "Jump to a compilation error."
  (interactive)
  (if (mcg-compile--consult-compile-error-p)
      (call-interactively #'consult-compile-error)
    (call-interactively #'next-error)))

;;;###autoload
(defun mcg-compile-build (&optional edit)
  "Build current project.
With prefix EDIT, edit the guessed command before running."
  (interactive "P")
  (mcg-compile--dispatch 'build edit))

;;;###autoload
(defun mcg-compile-test (&optional edit)
  "Test current project.
With prefix EDIT, edit the guessed command before running."
  (interactive "P")
  (mcg-compile--dispatch 'test edit))

;;;###autoload
(defun mcg-compile-run (&optional edit)
  "Run current project.
With prefix EDIT, edit the guessed command before running."
  (interactive "P")
  (mcg-compile--dispatch 'run edit))

(setq compilation-scroll-output mcg-compile-scroll-output)
(setq compilation-always-kill t)
(setq compilation-ask-about-save nil)

(define-prefix-command 'mcg-compile-map)
(mcg-bind-key "C-c c" 'mcg-compile-map "tools/compile")
(mcg-bind-key "C-c c c" #'mcg-compile "tools/compile")
(mcg-bind-key "C-c c r" #'mcg-recompile "tools/compile")
(mcg-bind-key "C-c c b" #'mcg-compile-build "tools/compile")
(mcg-bind-key "C-c c t" #'mcg-compile-test "tools/compile")
(mcg-bind-key "C-c c R" #'mcg-compile-run "tools/compile")
(mcg-bind-key "M-g e" #'mcg-compile-errors "tools/compile")

(mcg-log "compile module configured")

(provide 'init-compile)
;;; init-compile.el ends here
