;;; init-auto-save.el --- Auto-save configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure auto-save from:
;; emacs/site-lisp/extensions/utils/auto-save

;;; Code:

(require 'core-lib)

(defcustom mcg-auto-save-idle 1
  "Idle seconds before auto-save triggers."
  :type 'number
  :group 'mcg)

(defcustom mcg-auto-save-silent t
  "Whether auto-save should run silently."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-auto-save-delete-trailing-whitespace nil
  "Whether auto-save should delete trailing whitespace on save."
  :type 'boolean
  :group 'mcg)

(defun mcg--setup-auto-save ()
  "Setup auto-save plugin."
  (when (mcg-require-extension "auto-save" t)
    (setq auto-save-idle mcg-auto-save-idle)
    (setq auto-save-silent mcg-auto-save-silent)
    (setq auto-save-delete-trailing-whitespace
          mcg-auto-save-delete-trailing-whitespace)
    (auto-save-enable)
    (mcg-log "auto-save configured")))

(mcg--setup-auto-save)

(provide 'init-auto-save)
;;; init-auto-save.el ends here
