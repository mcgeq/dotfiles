;;; init-sort-tab.el --- sort-tab configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure sort-tab from:
;; emacs/site-lisp/extensions/utils/sort-tab

;;; Code:

(require 'core-lib)

(defun mcg--setup-sort-tab ()
  "Setup sort-tab."
  (when (mcg-require-extension "sort-tab" t)
    (when (fboundp 'sort-tab-mode)
      (sort-tab-mode 1))
    (mcg-log "sort-tab configured")))

(defun mcg--setup-sort-tab-keybinding ()
  "Setup sort-tab keybinding."
  (when (featurep 'sort-tab)
    (mcg-bind-key "C-c t n" 'sort-tab-select-next-tab "tools/sort-tab")
    (mcg-bind-key "C-c t p" 'sort-tab-select-prev-tab "tools/sort-tab")
    (mcg-bind-key "M-8" 'sort-tab-select-next-tab "tools/sort-tab")
    (mcg-bind-key "M-7" 'sort-tab-select-prev-tab "tools/sort-tab")
    (mcg-bind-key "C-c t k" 'sort-tab-close-current-tab "tools/sort-tab")
    (mcg-bind-key "C-c t o" 'sort-tab-close-other-tabs "tools/sort-tab")
    (mcg-bind-key "C-c t f" 'sort-tab-select-first-tab "tools/sort-tab")
    (mcg-bind-key "C-c t l" 'sort-tab-select-last-tab "tools/sort-tab")
    )
  (mcg-log "Sort tab keybindings configured"))

(mcg--setup-sort-tab)
(mcg--setup-sort-tab-keybinding)

(provide 'init-sort-tab)
;;; init-sort-tab.el ends here
