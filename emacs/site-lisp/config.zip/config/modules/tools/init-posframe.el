;;; init-posframe.el --- posframe configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure posframe from:
;; emacs/site-lisp/extensions/input/posframe

;;; Code:

(require 'core-lib)

(defun mcg--setup-posframe ()
  "Setup posframe."
  (if (mcg-require-extension "posframe" t)
      (mcg-log "posframe configured")
    (mcg-log-warning "posframe not available")))

(mcg--setup-posframe)

(provide 'init-posframe)
;;; init-posframe.el ends here
