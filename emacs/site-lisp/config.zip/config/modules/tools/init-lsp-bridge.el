;;; init-lsp-bridge.el --- LSP configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure lsp-bridge from git submodule:
;; emacs/site-lisp/extensions/lsp/lsp-bridge

;;; Code:

(require 'core-lib)
(require 'cl-lib)

;;; ============================================================
;;; Variables
;;; ============================================================

(defvar mcg-lsp-user-langserver-dir nil
  "User custom LSP server configuration directory.")

(defvar mcg-lsp-user-multiserver-dir nil
  "User custom multi-server configuration directory.")

(defcustom mcg-lsp-enable-with-tramp t
    "Whether lsp-bridge should be enabled for TRAMP buffers."
    :type 'boolean
    :group 'mcg)

  (defcustom mcg-lsp-enable-inlay-hint nil
    "Whether lsp-bridge inlay hints are enabled."
    :type 'boolean
    :group 'mcg)

  (defcustom mcg-lsp-enable-auto-format-code nil
    "Whether lsp-bridge should auto-format code after LSP edits.
Keep this disabled by default so formatting is owned by `mcg-format'."
    :type 'boolean
    :group 'mcg)

  (defcustom mcg-lsp-enable-org-babel nil
    "Whether lsp-bridge should enable LSP support for Org Babel blocks."
    :type 'boolean
    :group 'mcg)

  (defcustom mcg-lsp-enable-biome nil
    "Use biome with web."
    :type 'boolean
    :group 'mcg)

  (defcustom mcg-lsp-python-server "ty"
    "Python LSP server choice.
Options: \"ty\" (ty + ruff), \"basedpyright\" (basedpyright + ruff).
Can be overridden in private/config.el."
    :type 'string
    :group 'mcg)

;;; ============================================================
;;; Unified Keybindings
;;; ============================================================

(defvar mcg-lsp-keymap
  '(;; Navigation
    ("M-." . lsp-bridge-find-def)
    ("M-," . lsp-bridge-find-def-return)
    ("M-?" . lsp-bridge-find-references)

    ;; Documentation
    ("C-h ." . lsp-bridge-lookup-documentation)
    ("C-h ," . lsp-bridge-show-signature)

    ;; Refactoring
    ("C-c r r" . lsp-bridge-rename)
    ("C-c r a" . lsp-bridge-code-action)
    ("C-c r f" . mcg-format-buffer)

    ;; Diagnostics (M-g prefix - standard Emacs "goto" prefix)
    ("M-g n" . lsp-bridge-diagnostic-jump-next)
    ("M-g p" . lsp-bridge-diagnostic-jump-prev)
    ("M-g l" . lsp-bridge-diagnostic-list)

    ;; Workspace
    ("C-c r s" . lsp-bridge-workspace-list-symbols))

  "Unified LSP keybindings mapping.
All LSP-enabled language modes use the same keybindings:
- M-. Jump to definition
- M-, Return
- M-? Find references
- C-c r r Rename
- C-c r f Format
- C-c f H LSP Help")

(defun mcg-lsp-setup-keybindings ()
  "Setup unified LSP keybindings.
This function is called in lsp-bridge-mode-hook,
setting up keybindings defined in mcg-lsp-keymap for current buffer."
  (dolist (binding mcg-lsp-keymap)
    (local-set-key (kbd (car binding)) (cdr binding))))

(defun mcg-lsp-format-and-save-after-format (_filename _edits)
  "格式化完成后自动保存 buffer，兼容 auto-save 插件。"
  (when (and (buffer-file-name)
             (lsp-bridge-has-lsp-server-p)
             ;; 只有在 idle 触发时才自动保存（不是手动保存）
             (not (eq last-command 'save-buffer)))
    ;; 延迟一点时间再保存，让格式化完成
    (run-with-idle-timer 0.5 nil
                         (lambda ()
                           (when (buffer-modified-p)
                             (auto-save-save-buffer))))))

(defun mcg--setup-lsp-bridge ()
  "Setup lsp-bridge with robust fallback."
  (let ((lsp-bridge-path (or (mcg-extension-path "lsp-bridge")
                             (expand-file-name
                              "site-lisp/extensions/lsp/lsp-bridge"
                              mcg-emacs-dir))))
    (if (not (file-directory-p lsp-bridge-path))
        (mcg-log-warning "lsp-bridge path not found: %s" lsp-bridge-path)
      (add-to-list 'load-path lsp-bridge-path)
      (let ((acm-path (expand-file-name "acm" lsp-bridge-path)))
        (when (file-directory-p acm-path)
          (add-to-list 'load-path acm-path)))
      ;; lsp-bridge has a hard dependency on markdown-mode.
      (mcg-require-extension "markdown-mode" t)
      (if (require 'lsp-bridge nil t)
          (progn
            ;; Load acm-terminal in terminal (non-graphical environment)
            (unless (display-graphic-p)
              (mcg-require-extension 'acm-terminal t))

            (setq lsp-bridge-enable-with-tramp mcg-lsp-enable-with-tramp)
            (setq lsp-bridge-enable-inlay-hint mcg-lsp-enable-inlay-hint)
            ;; Optional snippet backend - only enable if yasnippet is already loaded
            ;; (init-yasnippet.el handles the initial configuration)
            (when (featurep 'yasnippet)
              (yas-global-mode 1))
            (global-lsp-bridge-mode)
            ;; Set custom server directories
            (when mcg-lsp-user-langserver-dir
              (setq lsp-bridge-user-langserver-dir mcg-lsp-user-langserver-dir))
            (when mcg-lsp-user-multiserver-dir
              (setq lsp-bridge-user-multiserver-dir mcg-lsp-user-multiserver-dir))
            (setq lsp-bridge-enable-completion-in-minibuffer t)
            (setq lsp-bridge-enable-org-babel mcg-lsp-enable-org-babel)
            (setq lsp-bridge-enable-auto-format-code mcg-lsp-enable-auto-format-code)

            ;; 方案C: 格式化后自动保存 (兼容 auto-save 插件)
            ;; 在格式化完成后自动保存 buffer
            (if mcg-lsp-enable-auto-format-code
                (unless (advice-member-p #'mcg-lsp-format-and-save-after-format
                                         'lsp-bridge-format--update)
                  (advice-add 'lsp-bridge-format--update :after #'mcg-lsp-format-and-save-after-format))
              (when (advice-member-p #'mcg-lsp-format-and-save-after-format
                                     'lsp-bridge-format--update)
                (advice-remove 'lsp-bridge-format--update
                               #'mcg-lsp-format-and-save-after-format)))
            ;; ===== Diagnostics Settings =====
            (setq lsp-bridge-enable-diagnostics t)
            (setq lsp-bridge-enable-hover-diagnostic t)
            (setq lsp-bridge-code-action-enable-popup-tip t)
            ;; ===== Completion Settings =====
            (setq lsp-bridge-enable-search-words t)
            (setq lsp-bridge-enable-auto-import t)
            (setq lsp-bridge-enable-completion-in-string t)
            (setq acm-enable-lsp-workspace-symbol t)
            (setq acm-candidate-match-function 'orderless-regexp)
            (setq acm-enable-preview t)
            ;; Multi-server configuration for TypeScript/JavaScript
            (when mcg-lsp-enable-biome
              (setq lsp-bridge-multi-lang-server-extension-list
                    (cl-remove-if (lambda (item)
                                    (member (car item) '("ts" "tsx" "js" "jsx" "vue")))
                                  lsp-bridge-multi-lang-server-extension-list))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list '("ts" . "typescript_biome"))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list '("tsx" . "typescriptreact_biome"))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list '("js" . "javascript_biome"))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list '("jsx" . "javascript_biome"))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list '("vue" . "vue_full")))
            ;; Multi-server configuration for Python
            (when (member mcg-lsp-python-server '("ty" "basedpyright"))
              (setq lsp-bridge-multi-lang-server-extension-list
                    (cl-remove-if (lambda (item)
                                    (member (car item) '("py" "pyw")))
                                  lsp-bridge-multi-lang-server-extension-list))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list
                           (cons "py" (concat mcg-lsp-python-server "_ruff")))
              (add-to-list 'lsp-bridge-multi-lang-server-extension-list
                           (cons "pyw" (concat mcg-lsp-python-server "_ruff"))))
            ;; Setup keybindings hook
            (add-hook 'lsp-bridge-mode-hook #'mcg-lsp-setup-keybindings)
            (mcg-log "lsp-bridge configured"))
        (mcg-log-error "Failed to load lsp-bridge from %s" lsp-bridge-path)))))

;; Set default custom server directories
(setq mcg-lsp-user-langserver-dir (expand-file-name "langservers" mcg-emacs-dir))
(setq mcg-lsp-user-multiserver-dir (expand-file-name "multiservers" mcg-emacs-dir))
(mcg--setup-lsp-bridge)

(provide 'init-lsp-bridge)
;;; init-lsp-bridge.el ends here
