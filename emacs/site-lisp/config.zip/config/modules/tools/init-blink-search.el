;;; init-blink-search.el --- Blink-search configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure blink-search from:
;; emacs/site-lisp/extensions/search/blink-search

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Blink-Search Configuration
;;; ============================================================

(defun mcg--setup-blink-search ()
  "Setup Blink-search fast search framework."
  (when (mcg-require-extension "blink-search" t)
    ;; Common directories
    (setq blink-search-common-directory
          `(("HOME" "~/")
            ("CONFIG" ,mcg-config-dir)
            ("DOWNLOADS" "~/Downloads/")
            ("DOCUMENTS" "~/Documents/")
            ("DESKTOP" "~/Desktop/")))

    ;; Python command
    (setq blink-search-python-command
          (if (memq system-type '(cygwin windows-nt ms-dos))
              "python.exe"
            "python3"))

    ;; Display settings
    (setq blink-search-enable-icon t)
    (setq blink-search-enable-posframe t)
    (setq blink-search-posframe-width-ratio 0.8)
    (setq blink-search-posframe-height-ratio 0.6)
    (setq blink-search-posframe-standalone nil)
    (setq blink-search-flash-line-delay 0.3)

    ;; Search backends (nil = use all backends)
    (setq blink-search-search-backends nil)

    ;; File manager
    (setq blink-search-file-manager 'dired)

    ;; History file path
    (setq blink-search-history-path
          (expand-file-name "blink-search/history.txt" user-emacs-directory))

    ;; Database path
    (setq blink-search-db-path
          (expand-file-name "blink-search.db" user-emacs-directory))
    (setq blink-search-db-table "kvstore")

    ;; Debug settings
    (setq blink-search-enable-debug nil)
    (setq blink-search-enable-log nil)

    (mcg-log "Blink-search configured")))

;;; ============================================================
;;; Blink-Search Helper Functions
;;; ============================================================

(defun mcg/blink-search-grep-current-dir ()
  "Search files in current directory using blink-search."
  (interactive)
  (let ((default-directory (or (when buffer-file-name
                                 (file-name-directory buffer-file-name))
                               default-directory)))
    (blink-search)))

(defun mcg/blink-search-project-root ()
  "Search files in project root using blink-search."
  (interactive)
  (let ((default-directory (mcg-project-root-or-default)))
    (blink-search)))

;;; ============================================================
;;; Keybindings (extend C-c s search prefix)
;;; ============================================================

(defun mcg--setup-blink-search-keybindings ()
  "Setup Blink-search keybindings."
  ;; Extend the shared C-c s search prefix from init-consult.
  (when (featurep 'blink-search)
    (mcg-bind-key "C-c s b" 'blink-search "tools/blink-search")
    (mcg-bind-key "C-c s d" 'mcg/blink-search-grep-current-dir "tools/blink-search")
    (mcg-bind-key "C-c s p" 'mcg/blink-search-project-root "tools/blink-search"))

    (mcg-log "Blink-search keybindings configured"))

(mcg--setup-blink-search)
(mcg--setup-blink-search-keybindings)

(provide 'init-blink-search)
;;; init-blink-search.el ends here
