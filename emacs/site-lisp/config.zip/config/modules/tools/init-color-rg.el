;;; init-color-rg.el --- color-rg configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure color-rg from:
;; emacs/site-lisp/extensions/search/color-rg

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Color-rg Configuration
;;; ============================================================

(defun mcg--setup-color-rg ()
  "Setup Color-rg project content search."
  (when (mcg-require-extension "color-rg" t)
    ;; Don't limit file types
    (setq color-rg-search-file-regexp nil)

    ;; Ignore directories
    (setq color-rg-search-ignore-dirs
          '(".git" ".svn" ".hg" "node_modules" "dist" "build" ".cache"
            "target" ".idea" ".vscode" "__pycache__" ".pytest_cache"
            "eln-cache" "elpa" "straight"))

    ;; Ignore files
    (setq color-rg-search-ignore-files
          '("*.pyc" "*.o" "*.elc" "*.class" "*.jar" "*.war" "*.ear"
            "*.min.js" "*.min.css" "*.log" "*.lock" "package-lock.json"
            "*.png" "*.jpg" "*.gif" "*.pdf" "*.zip" "*.tar.gz"))

    ;; Kill temp buffer on exit
    (setq color-rg-kill-temp-buffer-p t)

    ;; Mac uses GNU grep
    (when (eq system-type 'darwin)
      (when (executable-find "ggrep")
        (setq color-rg-mac-grep "ggrep")))

    ;; Window height
    (setq color-rg-window-height 15)

    ;; Show line numbers in result buffer
    (add-hook 'color-rg-mode-hook
              (lambda ()
                (when (fboundp 'display-line-numbers-mode)
                  (display-line-numbers-mode 1))))

    ;; Performance optimization
    (setq color-rg-regexp-match-limit 10000)

    ;; Use ripgrep
    (when (executable-find "rg")
      (setq color-rg-search-command "rg"))

    (mcg-log "Color-rg configured")))

;;; ============================================================
;;; Color-rg Helper Functions
;;; ============================================================

(defun mcg/color-rg-search-project ()
  "Search input in current project with Color-rg."
  (interactive)
  (color-rg-search-input (color-rg-read-input) (mcg-project-root-or-default)))

(defun mcg/color-rg-search-symbol-in-project ()
  "Search symbol at point in current project with Color-rg."
  (interactive)
  (color-rg-search-input (color-rg-pointer-string) (mcg-project-root-or-default)))

(defun mcg/color-rg-search-project-with-type ()
  "Search in project by file type."
  (interactive)
  (let ((file-type (completing-read "File type: "
                                    '("*.el" "*.org" "*.js" "*.ts" "*.py" "*.go"
                                      "*.rs" "*.java" "*.c" "*.cpp" "*.h"
                                      "*.md" "*.txt" "*.json" "*.yaml" "*.toml"))))
    (color-rg-search-input (color-rg-read-input)
                           (mcg-project-root-or-default)
                           file-type)))

(defun mcg/color-rg-search-in-org-directory ()
  "Search in org directory."
  (interactive)
  (let ((org-dir (if (boundp 'org-directory)
                     org-directory
                   (expand-file-name "~/org"))))
    (when (file-directory-p org-dir)
      (let ((default-directory org-dir))
        (call-interactively 'color-rg-search-input)))))

(defun mcg/color-rg-search-in-config ()
  "Search in Emacs configuration directory."
  (interactive)
  (let ((default-directory mcg-config-dir))
    (call-interactively 'color-rg-search-input)))

;;; ============================================================
;;; Keybindings (extend C-c s search prefix)
;;; ============================================================

(defun mcg--setup-color-rg-keybindings ()
  "Setup Color-rg keybindings."
  ;; Extend the shared C-c s search prefix from init-consult.
  (when (mcg-require-extension "color-rg" t)
    ;; Project content search
    (mcg-bind-key "C-c s g" 'color-rg-search-input "tools/color-rg")
    (mcg-bind-key "C-c s G" 'mcg/color-rg-search-project "tools/color-rg")

    ;; Symbol search (using 's' for symbol)
    (mcg-bind-key "C-c s s" 'color-rg-search-symbol "tools/color-rg")
    (mcg-bind-key "C-c s S" 'mcg/color-rg-search-symbol-in-project "tools/color-rg")

    ;; Current file
    (mcg-bind-key "C-c s ." 'color-rg-search-symbol-in-current-file "tools/color-rg")
    (mcg-bind-key "C-c s ," 'color-rg-search-input-in-current-file "tools/color-rg")

    ;; Custom search
    (mcg-bind-key "C-c s t" 'mcg/color-rg-search-project-with-type "tools/color-rg")
    (mcg-bind-key "C-c s O" 'mcg/color-rg-search-in-org-directory "tools/color-rg")
    (mcg-bind-key "C-c s c" 'mcg/color-rg-search-in-config "tools/color-rg"))

  (mcg-log "Color-rg keybindings configured"))

(mcg--setup-color-rg)
(mcg--setup-color-rg-keybindings)

(provide 'init-color-rg)
;;; init-color-rg.el ends here
