;;; init-mcgju.el --- mcgju configuration -*- lexical-binding: t; -*-

;; Filename: init-mcgju.el
;; Description: Modern Jujutsu (jj) workbench integration
;; Author: mcge <mcgeq@outlook.com>
;; Copyright (C) 2024-2026, mcge, all rights reserved.
;; Create   Date: 2026-07-11
;; Version: 0.1
;; Keywords: jujutsu, jj, version-control, magit-section
;; Compatibility: Emacs 29.1+, jj 0.37.0+

;;; Commentary:
;;
;; mcgju provides a modern Magit-section based workbench for Jujutsu.
;; It is developed locally under:
;;   emacs/site-lisp/extensions/git/mcgju
;;
;; Module metadata:
;; :depends (magit transient)
;; :defer t

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Variables
;;; ============================================================

(defvar mcg-tools-mcgju-prefix "C-x J"
  "Primary key for opening the mcgju workbench.")

;;; ============================================================
;;; Initialize
;;; ============================================================

(defun mcg--setup-mcgju ()
  "Setup mcgju - modern Jujutsu workbench."
  ;; Load Magit/Transient dependencies explicitly so this module is stable when
  ;; idle-loaded independently of tools/magit.
  (mcg-require-extension 'compat t)
  (mcg-require-extension 'cond-let t)
  (mcg-require-extension 'llama t)
  (require 'seq nil t)
  (mcg-require-extension 'transient t)
  (mcg-require-extension 'with-editor t)
  (mcg-require-extension 'magit t)
  (if (mcg-require-extension 'mcgju t)
      (progn
        (mcg-bind-key mcg-tools-mcgju-prefix #'mcgju "tools/mcgju")
        (mcg-bind-key "C-c j j" #'mcgju "tools/mcgju")
        (mcg-bind-key "C-c j ?" #'mcgju-dispatch "tools/mcgju")
        (mcg-bind-key "C-c j r" #'mcgju-workbench-set-revset "tools/mcgju")
        (mcg-log "mcgju configured with keybinding %s" mcg-tools-mcgju-prefix))
    (mcg-log-error "Failed to load mcgju - ensure jj and dependencies are installed")))

(mcg--setup-mcgju)

(provide 'init-mcgju)
;;; init-mcgju.el ends here
