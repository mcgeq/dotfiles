;;; init-ef-themes.el --- ef-themes configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure ef-themes from:
;; emacs/site-lisp/extensions/ui/themes/ef-themes

;;; Code:

(require 'core-lib)

(defcustom mcg-ui-theme 'ef-dream
  "Default theme from ef-themes."
  :type 'symbol
  :group 'mcg)

(defun mcg-ui-switch-theme ()
  "Switch the current theme."
  (interactive)
  (if (fboundp 'consult-theme)
      (call-interactively #'consult-theme)
    (let* ((themes (cons "default"
                         (mapcar #'symbol-name (custom-available-themes))))
           (choice (completing-read "Theme: " themes nil t nil nil
                                    (symbol-name mcg-ui-theme)))
           (theme (unless (string= choice "default")
                    (intern choice))))
      (mapc #'disable-theme custom-enabled-themes)
      (when theme
        (load-theme theme t)))))

(defun mcg--setup-ef-themes ()
  "Setup ef-themes."
  (let ((has-modus (mcg-require-extension "modus-themes" t))
        (has-ef (mcg-require-extension "ef-themes" t)))
    (cond
     ((not has-modus)
      (mcg-log-error "Missing dependency: modus-themes (required by ef-themes)"))
     ((not has-ef)
      (mcg-log-error "Missing extension: ef-themes"))
     (t
      (mapc #'disable-theme custom-enabled-themes)
      (load-theme mcg-ui-theme t)
      (with-eval-after-load 'consult
        (when (fboundp 'consult-theme)
          (consult-customize consult-theme :preview-key '(:debounce 0.5 any))))
      (mcg-log "ef-themes configured: %s" mcg-ui-theme)))))

(mcg--setup-ef-themes)
(mcg-bind-key "C-c T" #'mcg-ui-switch-theme "ui/theme")

(provide 'init-ef-themes)
;;; init-ef-themes.el ends here
