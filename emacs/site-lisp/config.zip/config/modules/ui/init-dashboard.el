;;; init-dashboard.el --- dashboard configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure dashboard from:
;; emacs/site-lisp/extensions/ui/dashboard

;;; Code:

(require 'core-lib)

(defcustom mcg-dashboard-enabled t
  "Whether to enable dashboard."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-dashboard-startup t
  "Whether to show dashboard at startup."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-dashboard-items
  '((recents . 5)
    (projects . 5)
    (bookmarks . 5))
  "Dashboard sections and item counts.
Agenda is intentionally not enabled by default to keep startup light."
  :type '(repeat (cons symbol integer))
  :group 'mcg)

(defcustom mcg-dashboard-icon-type 'nerd-icons
  "Icon backend used by dashboard.
The default prefers `nerd-icons'. Set nil to disable dashboard icons."
  :type '(choice (const :tag "Nerd Icons" nerd-icons)
                 (const :tag "No icons" nil))
  :group 'mcg)

(defcustom mcg-dashboard-startup-banner 'ascii
  "Banner type used by dashboard."
  :type '(choice (const :tag "ASCII text" ascii)
                 (const :tag "Official logo" official)
                 (const :tag "No banner" nil)
                 (string :tag "Image file path"))
  :group 'mcg)

(defcustom mcg-dashboard-banner-ascii
  (concat
   " _      ____  _____ _____ _      ____  ____  ____ \n"
   "/ \\__/|/   _\\/  __//  __// \\__/|/  _ \\/   _\\/ ___\\\n"
   "| |\\/|||  /  | |  _|  \\  | |\\/||| / \\||  /  |    \\\n"
   "| |  |||  \\_ | |*//|  /* | |  ||| |-|||  \\_ \\___ |\n"
   "\\_/  \\|\\____/\\____\\\\____\\\\_/  \\|\\_/ \\|\\____/\\____/\n"
   "                                                  ")
  "ASCII banner text displayed when `mcg-dashboard-startup-banner' is `ascii'."
  :type 'string
  :group 'mcg)

(defcustom mcg-dashboard-banner-title nil
  "Banner title displayed by dashboard."
  :type '(choice (const :tag "No title" nil)
                 (string :tag "Title"))
  :group 'mcg)

(defcustom mcg-dashboard-footer-messages '("By mcge")
  "Footer messages displayed by dashboard."
  :type '(repeat string)
  :group 'mcg)

(defcustom mcg-dashboard-nerd-icons-heading-icons
  '((recents . "nf-oct-history")
    (bookmarks . "nf-oct-bookmark")
    (agenda . "nf-oct-calendar")
    (projects . "nf-oct-rocket")
    (registers . "nf-oct-database"))
  "Nerd icons used for dashboard section headings."
  :type '(alist :key-type symbol :value-type string)
  :group 'mcg)

(defun mcg-dashboard-icons-enabled-p ()
  "Return non-nil when dashboard icons should be enabled."
  (and mcg-dashboard-icon-type
       (require mcg-dashboard-icon-type nil t)))

(defun mcg-dashboard-setup-recentf ()
  "Configure recentf state used by dashboard before startup rendering."
  (unless mcg-cache-dir
    (mcg-init-paths))
  (make-directory mcg-cache-dir t)
  (setq recentf-max-saved-items 300)
  (setq recentf-save-file (expand-file-name "recentf.el" mcg-cache-dir))
  (setq recentf-auto-cleanup 'never)
  (setq recentf-filename-handlers '(abbreviate-file-name)))

(defun mcg-dashboard-enable-resize-refresh ()
  "Enable dashboard refreshes after startup window setup has settled."
  (when (fboundp 'dashboard-resize-on-hook)
    (add-hook 'window-size-change-functions #'dashboard-resize-on-hook 100)))

(defun mcg-dashboard-open-startup-buffer ()
  "Open dashboard early enough to avoid a blank startup frame."
  (add-hook 'window-setup-hook #'mcg-dashboard-enable-resize-refresh 100)
  (when (fboundp 'dashboard-insert-startupify-lists)
    (dashboard-insert-startupify-lists t)
    (switch-to-buffer
     (if (boundp 'dashboard-buffer-name)
         dashboard-buffer-name
       "*dashboard*")))
  (if (fboundp 'mcg-release-startup-redisplay)
      (mcg-release-startup-redisplay)
    (setq inhibit-redisplay nil
          inhibit-message nil)
    (redisplay)))

(defun mcg--setup-dashboard ()
  "Setup dashboard."
  (if (and mcg-dashboard-enabled
           (mcg-require-extension "dashboard" t))
      (progn
        (mcg-dashboard-setup-recentf)
        (setq dashboard-banner-logo-title mcg-dashboard-banner-title)
        (setq dashboard-startup-banner mcg-dashboard-startup-banner)
        (setq dashboard-banner-ascii mcg-dashboard-banner-ascii)
        (setq dashboard-footer-messages mcg-dashboard-footer-messages)
        (setq dashboard-items mcg-dashboard-items)
        (setq dashboard-projects-backend 'project-el)
        (setq dashboard-center-content t)
        (setq dashboard-show-shortcuts nil)
        (setq dashboard-set-heading-icons (mcg-dashboard-icons-enabled-p))
        (setq dashboard-set-file-icons dashboard-set-heading-icons)
        (setq dashboard-icon-type
              (when dashboard-set-heading-icons mcg-dashboard-icon-type))
        (when (eq dashboard-icon-type 'nerd-icons)
          (setq dashboard-heading-icons mcg-dashboard-nerd-icons-heading-icons))
        (when mcg-dashboard-startup
          (mcg-dashboard-open-startup-buffer))
        (mcg-log "dashboard configured"))
    (mcg-log-warning "dashboard not available or disabled")))

(defun mcg/dashboard-open ()
  "Open dashboard."
  (interactive)
  (if (fboundp 'dashboard-open)
      (dashboard-open)
    (message "dashboard is not available")))

(mcg--setup-dashboard)

(provide 'init-dashboard)
;;; init-dashboard.el ends here
