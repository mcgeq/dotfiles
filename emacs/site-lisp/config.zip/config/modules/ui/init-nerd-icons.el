;;; init-nerd-icons.el --- nerd-icons configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure nerd-icons from:
;; emacs/site-lisp/extensions/ui/themes/nerd-icons

;;; Code:

(require 'core-lib)
(require 'init-font)  ; Load font utilities for mcg-get-icon-font

(defun mcg--setup-nerd-icons ()
  "Setup nerd-icons."
  (if (mcg-require-extension "nerd-icons" t)
      (progn
        ;; Use unified icon font from init-font.el
        (setq nerd-icons-font-family (mcg-get-icon-font))
        (if (and (boundp 'nerd-icons-font-family)
                 (find-font (font-spec :family nerd-icons-font-family)))
            (mcg-log "nerd-icons configured: %s" nerd-icons-font-family)
          (unless noninteractive
            (mcg-log-warning "nerd-icons font missing, run M-x nerd-icons-install-fonts"))))
    (mcg-log-warning "nerd-icons not available")))

(mcg--setup-nerd-icons)

(provide 'init-nerd-icons)
;;; init-nerd-icons.el ends here
