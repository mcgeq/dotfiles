;;; init-consult.el --- consult configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure consult from:
;; emacs/site-lisp/extensions/completion/consult

;;; Code:

(require 'core-lib)
(require 'subr-x)

(defun mcg--setup-consult ()
    "Setup Consult consulting search commands."
    (when (mcg-require-extension "consult" t)
      ;; Preview configuration
      (setq consult-narrow-key "<")
      (setq consult-widen-key ">")

      ;; Preview limits
      (setq consult-preview-max-size 10485760)  ; 10 MB
      (setq consult-preview-max-count 10)

      ;; Async command configuration
      (setq consult-async-refresh-delay 0.15)
      (setq consult-async-input-throttle 0.2)
      (setq consult-async-input-debounce 0.1)

      ;; Register integration
      (setq register-preview-delay 0.5
            register-preview-function #'consult-register-format)
      (advice-add #'register-preview :override #'consult-register-window)

      ;; Xref integration
      (setq xref-show-xrefs-function #'consult-xref
            xref-show-definitions-function #'consult-xref)
      (setq completion-in-region-function #'consult-completion-in-region)

      ;; Buffer filter - hide internal buffers
      (setq consult-buffer-filter
            '("\\` "
              "\\`\\*Completions\\*\\'"
              "\\`\\*Flymake log\\*\\'"
              "\\`\\*Semantic SymRef\\*\\'"
              "\\`\\*tramp/.*\\*\\'"
              "\\`\\*Messages\\*\\'"
              "\\`\\*Warnings\\*\\'"
              "\\`\\*Backtrace\\*\\'"
              "\\`\\*Native-compile-Log\\*\\'"))

      ;; Project function for project-based filtering
      (setq consult-project-function
            (lambda (_)
              (when-let* ((project (project-current)))
               (project-root project))))

      (mcg-log "Consult configured")))

  (defun mcg--setup-consult-keybinding ()
    "Setup consult."
      (when (mcg-require-extension "consult" t)
        (require 'consult-register nil t)

        (mcg-bind-key "C-x b" #'consult-buffer "completion/consult")
        (mcg-bind-key "C-x 4 b" #'consult-buffer-other-window "completion/consult")
        (mcg-bind-key "C-x 5 b" #'consult-buffer-other-frame "completion/consult")
        (mcg-bind-key "C-x r b" #'consult-bookmark "completion/consult")
        (mcg-bind-key "C-x p b" #'consult-project-buffer "completion/consult")
        (define-key minibuffer-local-map (kbd "C-r") #'consult-history)

        ;; 搜索与导航 (C-c s prefix - search)
        (define-prefix-command 'mcg-search-map)
        (mcg-bind-key "C-c s" 'mcg-search-map "completion/consult")
        (mcg-bind-key "C-s" #'consult-line "completion/consult")
        (mcg-bind-key "C-c s l" #'consult-line "completion/consult")
        (mcg-bind-key "C-c s r" #'consult-ripgrep "completion/consult")
        (mcg-bind-key "C-c s i" #'consult-imenu "completion/consult")
        (mcg-bind-key "C-c s o" #'consult-outline "completion/consult")

        ;; Standard M-g navigation bindings
        (mcg-bind-key "M-g g" #'consult-goto-line "completion/consult")
        (mcg-bind-key "M-g M-g" #'consult-goto-line "completion/consult")
        (mcg-bind-key "M-g o" #'consult-outline "completion/consult")
        (mcg-bind-key "M-g i" #'consult-imenu "completion/consult")
        (mcg-bind-key "M-g I" #'consult-imenu-multi "completion/consult")
        (mcg-bind-key "M-g m" #'consult-mark "completion/consult")
        (mcg-bind-key "M-g k" #'consult-global-mark "completion/consult")

        ;; Standard M-s search bindings
        (mcg-bind-key "M-s f" #'consult-find "completion/consult")
        (mcg-bind-key "M-s g" #'consult-grep "completion/consult")
        (mcg-bind-key "M-s G" #'consult-git-grep "completion/consult")
        (mcg-bind-key "M-s r" #'consult-ripgrep "completion/consult")
        (mcg-bind-key "M-s l" #'consult-line "completion/consult")
        (mcg-bind-key "M-s L" #'consult-line-multi "completion/consult")
        (mcg-bind-key "M-s k" #'consult-keep-lines "completion/consult")
        (mcg-bind-key "M-s u" #'consult-focus-lines "completion/consult")

        ;; 缓冲区与文件 (C-c b / C-c f prefix)
        ;; C-c b is a prefix key for buffer operations
        (define-prefix-command 'mcg-consult-buffer-map)
        (mcg-bind-key "C-c b" 'mcg-consult-buffer-map "completion/consult")
        (define-key mcg-consult-buffer-map "b" #'consult-buffer)
        (define-key mcg-consult-buffer-map "m" #'consult-bookmark)
        (define-key mcg-consult-buffer-map "r" #'consult-recent-file)
        
        ;; C-c f for file operations
        (mcg-bind-key "C-c f f" #'consult-find "completion/consult")
        (mcg-bind-key "C-c f r" #'consult-recent-file "completion/consult")

        ;; 粘贴与历史
        (mcg-bind-key "M-y" #'consult-yank-pop "completion/consult")

      ;; 命令与寄存器
      ;; C-c x is a prefix; binding it directly to a command makes C-c x c unreachable.
      (define-prefix-command 'mcg-consult-command-map)
      (mcg-bind-key "C-c x" 'mcg-consult-command-map "completion/consult")
      (mcg-bind-key "C-x M-:" #'consult-complex-command "completion/consult")
      (mcg-bind-key "C-c x c" #'consult-complex-command "completion/consult")
      (mcg-bind-key "C-c x x" #'consult-mode-command "completion/consult")
      (mcg-bind-key "M-#" #'consult-register-load "completion/consult")
      (mcg-bind-key "M-'" #'consult-register-store "completion/consult")
      (mcg-bind-key "C-M-#" #'consult-register "completion/consult")
      (mcg-bind-key "C-c ; r" #'consult-register "completion/consult")

      (mcg-log "consult configured")))

(mcg--setup-consult)
(mcg--setup-consult-keybinding)

(provide 'init-consult)
;;; init-consult.el ends here
