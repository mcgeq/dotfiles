;;; init-embark.el --- embark configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure embark from:
;; emacs/site-lisp/extensions/completion/embark

;;; Code:

(require 'core-lib)

(defun mcg--setup-embark ()
  "Setup embark."
  (when (mcg-require-extension "embark" t)
    (mcg-bind-key "C-." #'embark-act "completion/embark")
    (mcg-bind-key "C-;" #'embark-dwim "completion/embark")
    (setq prefix-help-command #'embark-prefix-help-command)
    (define-key global-map [remap describe-bindings] #'embark-bindings)
    (when (require 'embark-consult nil t)
      (add-hook 'embark-collect-mode-hook #'consult-preview-at-point-mode))
    (mcg-log "embark configured")))

(mcg--setup-embark)

(provide 'init-embark)
;;; init-embark.el ends here
