;;; init-yasnippet.el --- Snippet System for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: snippets, yasnippet
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Code snippet module for MCG Emacs configuration, responsible for:
;; - YASnippet configuration
;; - Custom snippet directories
;; - Git user info integration

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Variables
;;; ============================================================

(defvar mcg-snippet-dirs nil
  "Custom code snippet directory list.")

;;; ============================================================
;;; Git User Functions
;;; ============================================================

(defun mcg/get-git-user-name ()
  "Get Git configured username."
  (interactive)
  (replace-regexp-in-string
   "\n$" ""
   (shell-command-to-string "git config --get user.name")))

(defun mcg/get-git-user-email ()
  "Get Git configured email."
  (interactive)
  (replace-regexp-in-string
   "\n$" ""
   (shell-command-to-string "git config --get user.email")))

;;; ============================================================
;;; YASnippet Configuration
;;; ============================================================

(defun mcg--setup-yasnippet ()
  "Set up YASnippet code snippet system."
  (when (mcg-require-extension "yasnippet" t)
    ;; Set custom snippet directories
    (let ((custom-dirs
           (list (expand-file-name "site-lisp/snippets" mcg-emacs-dir)
                 (expand-file-name "site-lisp/extensions/snippets/yasnippet-snippets"
                                   mcg-emacs-dir))))
      (dolist (dir custom-dirs)
        (when (file-directory-p dir)
          (add-to-list 'yas-snippet-dirs dir))))
    
    ;; Reload snippets
    (yas-reload-all)
    
    ;; Enable globally
    (yas-global-mode 1)
    
    ;; Disable in certain modes
    (dolist (hook '(term-mode-hook eshell-mode-hook))
      (add-hook hook (lambda () (yas-minor-mode -1))))
    
    (mcg-log "YASnippet configured")))

;;; ============================================================
;;; YASnippet Keybindings
;;; ============================================================

(defun mcg--setup-yasnippet-keybindings ()
  "Setup YASnippet keybindings."
  (when (featurep 'yasnippet)
    ;; Snippet expansion and navigation
    (define-key yas-minor-mode-map (kbd "<tab>") nil)
    (define-key yas-minor-mode-map (kbd "TAB") nil)
    (define-key yas-minor-mode-map (kbd "C-c y n") #'yas-new-snippet)
    (define-key yas-minor-mode-map (kbd "C-c y v") #'yas-visit-snippet-file)
    (define-key yas-minor-mode-map (kbd "C-c y i") #'yas-insert-snippet)
    (define-key yas-minor-mode-map (kbd "C-c y e") #'yas-expand)
    (mcg-log "YASnippet keybindings configured")))

;;; ============================================================
;;; YASnippet Custom Functions
;;; ============================================================

(defun mcg/yas-reload-all ()
  "Reload all snippets."
  (interactive)
  (yas-reload-all)
  (message "YASnippet: All snippets reloaded"))

(defun mcg/yas-describe-tables ()
  "Display snippet tables for current mode."
  (interactive)
  (yas-describe-tables))

;;; ============================================================
;;; Initialize
;;; ============================================================

(mcg--setup-yasnippet)
(mcg--setup-yasnippet-keybindings)

(provide 'init-yasnippet)
;;; init-yasnippet.el ends here
