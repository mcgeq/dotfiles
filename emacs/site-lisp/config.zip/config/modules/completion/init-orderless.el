;;; init-orderless.el --- orderless configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure orderless from:
;; emacs/site-lisp/extensions/completion/orderless

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Orderless Configuration
;;; ============================================================

(defun mcg--setup-orderless ()
  "Setup Orderless fuzzy matching engine."
  (when (mcg-require-extension "orderless" t)
    ;; Core completion styles
    (setq completion-styles '(orderless partial-completion basic)
          completion-category-defaults nil)

    ;; Component separator (space or &)
    (setq orderless-component-separator "[ &]")

    ;; File completion uses partial-completion style
    (setq completion-category-overrides
          '((file (styles partial-completion))
            (buffer (styles orderless))
            (info-menu (styles orderless))))

    ;; Matching styles
    (setq orderless-matching-styles
          '(orderless-literal
            orderless-regexp
            orderless-initialism))

    ;; Style dispatchers (! negation, = literal, ~ flex)
    (setq orderless-style-dispatchers
          '(orderless-affix-dispatch))

    (mcg-log "Orderless configured")))

(mcg--setup-orderless)

(provide 'init-orderless)
;;; init-orderless.el ends here
