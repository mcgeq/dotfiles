;;; init-nerd-icons-completion.el --- nerd-icons-completion -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure nerd-icons-completion from:
;; emacs/site-lisp/extensions/ui/themes/nerd-icons-completion

;;; Code:

(require 'core-lib)

(defun mcg--setup-nerd-icons-completion ()
  "Setup nerd-icons-completion."
  (when (and (mcg-require-extension "nerd-icons" t)
             (mcg-require-extension "nerd-icons-completion" t))
    (nerd-icons-completion-mode 1)
    (with-eval-after-load 'marginalia
      (add-hook 'marginalia-mode-hook #'nerd-icons-completion-marginalia-setup))
    (mcg-log "nerd-icons-completion configured")))

(mcg--setup-nerd-icons-completion)

(provide 'init-nerd-icons-completion)
;;; init-nerd-icons-completion.el ends here
