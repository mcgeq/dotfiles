;;; init-pinyinlib.el --- pinyinlib configuration -*- lexical-binding: t; -*-

;;; Commentary:
;; Configure pinyinlib from:
;; emacs/site-lisp/extensions/completion/pinyinlib

;;; Code:

(require 'core-lib)

;;; ============================================================
;;; Variables
;;; ============================================================

(defvar mcg-completion-enable-pinyin t
  "Whether to enable pinyin completion.")

;;; ============================================================
;;; Pinyin Support (Chinese)
;;; ============================================================

(defun mcg/completion-regex-pinyin (str)
  "Pinyin match STR."
  (orderless-regexp (pinyinlib-build-regexp-string str)))

(defun mcg--setup-pinyin ()
  "Setup pinyin completion support."
  (when (and mcg-completion-enable-pinyin
             (mcg-require-extension "pinyinlib" t))

    ;; Add pinyin matching to orderless styles
    (unless (member 'mcg/completion-regex-pinyin orderless-matching-styles)
      (add-to-list 'orderless-matching-styles 'mcg/completion-regex-pinyin))

    (mcg-log "Pinyin completion enabled")))

(defun mcg/toggle-pinyin-completion ()
  "Toggle pinyin completion."
  (interactive)
  (if (member 'mcg/completion-regex-pinyin orderless-matching-styles)
      (progn
        (setq orderless-matching-styles
              (remove 'mcg/completion-regex-pinyin orderless-matching-styles))
        (message "Pinyin completion disabled"))
    (add-to-list 'orderless-matching-styles 'mcg/completion-regex-pinyin)
    (message "Pinyin completion enabled")))

(mcg--setup-pinyin)

(provide 'init-pinyinlib)
;;; init-pinyinlib.el ends here
