;;; init-zig.el --- Zig language support for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: languages, zig
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Zig language support module for MCG Emacs:
;; - zig-mode / zig-ts-mode configuration
;; - zls (Zig Language Server) LSP integration (via lsp-bridge)
;; - zig build integration
;; - Format on save with zig fmt
;;

;;; Code:

(require 'core-lib)
(mcg-require-extension 'zig-mode t)

;;; ============================================================
;;; Variables
;;; ============================================================

(defvar mcg-zig-format-on-save t
  "Whether to format Zig files on save using zig fmt.")

(defcustom mcg-zig-enable-lsp t
  "Whether Zig buffers should enable lsp-bridge when zls is available."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-zig-warn-missing-zls nil
  "Whether to show one warning when zls is missing for Zig LSP."
  :type 'boolean
  :group 'mcg)

(defvar mcg-zig--missing-zls-warned nil
  "Non-nil means the missing zls warning has already been shown.")

;;; ============================================================
;;; zig-mode / zig-ts-mode Configuration
;;; ============================================================

(defun mcg-zig--treesit-available-p ()
  "Return non-nil when Zig tree-sitter grammar is available."
  (and (fboundp 'treesit-language-available-p)
       (treesit-language-available-p 'zig)))

(defun mcg-zig-deferred-mode ()
  "Select Zig major mode after the zig module is deferred-loaded."
  (if (and (fboundp 'zig-ts-mode)
           (mcg-zig--treesit-available-p))
      (zig-ts-mode)
    (zig-mode)))

(defun mcg-zig-mode-setup ()
  "Setup function for zig-mode and zig-ts-mode."
  ;; Indentation
  (setq-local indent-tabs-mode nil)
  (setq-local tab-width 4)

  ;; Enable subword mode for camelCase navigation
  (subword-mode 1)

  (mcg-zig-maybe-enable-lsp)

  (mcg-log "Zig mode setup complete"))

(defun mcg-zig--zls-available-p ()
  "Return non-nil when the Zig language server executable is available."
  (executable-find "zls"))

(defun mcg-zig-maybe-enable-lsp ()
  "Enable lsp-bridge for Zig when zls and lsp-bridge are available."
  (cond
   ((not mcg-zig-enable-lsp)
    nil)
   ((mcg-zig--zls-available-p)
    (when (fboundp 'lsp-bridge-mode)
      (lsp-bridge-mode 1)))
   ((and mcg-zig-warn-missing-zls
         (not mcg-zig--missing-zls-warned))
    (setq mcg-zig--missing-zls-warned t)
    (mcg-log-warning "zls executable not found; Zig LSP disabled"))))

;; File associations are managed by treesit-auto in init-treesit.el.
;; This module only configures mode behavior.
(add-hook 'zig-mode-hook #'mcg-zig-mode-setup)
(add-hook 'zig-ts-mode-hook #'mcg-zig-mode-setup)

;; zig-mode extension
(let ((zig-mode-path (mcg-extension-path "zig-mode")))
  (when zig-mode-path
    (add-to-list 'load-path zig-mode-path)))

(with-eval-after-load 'zig-mode
  (setq zig-format-on-save mcg-zig-format-on-save)
  (setq zig-format-show-buffer nil))

;;; ============================================================
;;; Zig Build Integration
;;; ============================================================

(defun mcg--zig-find-build-root ()
  "Find the root directory containing build.zig."
  (or (locate-dominating-file default-directory "build.zig")
      default-directory))

(defun mcg-zig--compile (command &optional root)
  "Run Zig compile COMMAND in ROOT through the unified compile layer."
  (let ((root (file-name-as-directory
               (or root (mcg--zig-find-build-root)))))
    (if (fboundp 'mcg-compile--run)
        (mcg-compile--run command root)
      (let ((default-directory root))
        (compile command)))))

(defun mcg-zig-build-command (action)
  "Return Zig build command for ACTION."
  (pcase action
    ('build "zig build")
    ('run "zig build run")
    ('test "zig build test")))

(defun mcg/zig-build ()
  "Run zig build."
  (interactive)
  (mcg-zig--compile (mcg-zig-build-command 'build)))

(defun mcg/zig-build-run ()
  "Run zig build run."
  (interactive)
  (mcg-zig--compile (mcg-zig-build-command 'run)))

(defun mcg/zig-build-test ()
  "Run zig build test."
  (interactive)
  (mcg-zig--compile (mcg-zig-build-command 'test)))

(defun mcg/zig-test ()
  "Run zig test on current file."
  (interactive)
  (let ((file (buffer-file-name)))
    (when file
      (save-buffer)
      (mcg-zig--compile (format "zig test %s" (shell-quote-argument file))))))

(defun mcg/zig-run ()
  "Run current Zig file."
  (interactive)
  (let ((file (buffer-file-name)))
    (when file
      (save-buffer)
      (mcg-zig--compile (format "zig run %s" (shell-quote-argument file))))))

;;; ============================================================
;;; Zig Build Steps
;;; ============================================================

(defun mcg/zig-build-step (step)
  "Run zig build with STEP."
  (interactive "sBuild step: ")
  (mcg-zig--compile (format "zig build %s" step)))

(defun mcg/zig-build-release ()
  "Run zig build with release mode."
  (interactive)
  (mcg-zig--compile "zig build -Doptimize=ReleaseSafe"))

(defun mcg/zig-build-release-fast ()
  "Run zig build with release-fast mode."
  (interactive)
  (mcg-zig--compile "zig build -Doptimize=ReleaseFast"))

;;; ============================================================
;;; Zig Documentation
;;; ============================================================

(defun mcg/zig-doc ()
  "Open Zig documentation in browser."
  (interactive)
  (browse-url "https://ziglang.org/documentation/master/"))

(defun mcg/zig-std-doc ()
  "Open Zig standard library documentation in browser."
  (interactive)
  (browse-url "https://ziglang.org/documentation/master/std/"))

;;; ============================================================
;;; Zig Keybindings
;;; ============================================================

(defvar mcg-zig-mode-map
  (let ((map (make-sparse-keymap)))
    ;; Build
    (define-key map (kbd "C-c C-c b") #'mcg/zig-build)
    (define-key map (kbd "C-c C-c r") #'mcg/zig-build-run)
    (define-key map (kbd "C-c C-c t") #'mcg/zig-build-test)
    (define-key map (kbd "C-c C-c s") #'mcg/zig-build-step)
    (define-key map (kbd "C-c C-c R") #'mcg/zig-build-release)
    (define-key map (kbd "C-c C-c F") #'mcg/zig-build-release-fast)
    ;; Formatting
    (define-key map (kbd "C-c C-f") #'mcg-format-buffer)
    ;; Run/Test single file
    (define-key map (kbd "C-c C-r") #'mcg/zig-run)
    (define-key map (kbd "C-c C-t") #'mcg/zig-test)
    ;; Documentation
    (define-key map (kbd "C-c C-d d") #'mcg/zig-doc)
    (define-key map (kbd "C-c C-d s") #'mcg/zig-std-doc)
    map)
  "Keymap for Zig-specific commands.")

(defun mcg-zig-setup-keybindings ()
  "Setup Zig-specific keybindings."
  (use-local-map (make-composed-keymap mcg-zig-mode-map (current-local-map))))

;; Keybindings setup via hooks
(with-eval-after-load 'zig-mode
  (add-hook 'zig-mode-hook #'mcg-zig-setup-keybindings))
(when (mcg-treesit-available-p)
  (add-hook 'zig-ts-mode-hook #'mcg-zig-setup-keybindings))

;;; ============================================================
;;; Help Command
;;; ============================================================

(defun mcg/zig-help ()
  "Show Zig keybindings and command help."
  (interactive)
  (with-help-window "*MCG Zig Help*"
    (princ "
╔═══════════════════════════════════════════╗
║       MCG Zig Keybindings                 ║
╚═══════════════════════════════════════════╝

FORMAT:
  C-c C-f      - Format buffer

BUILD (project with build.zig):
  C-c C-c b    - zig build
  C-c C-c r    - zig build run
  C-c C-c t    - zig build test
  C-c C-c s    - zig build <step>
  C-c C-c R    - zig build (ReleaseSafe)
  C-c C-c F    - zig build (ReleaseFast)

SINGLE FILE:
  C-c C-r      - zig run <file>
  C-c C-t      - zig test <file>

DOCUMENTATION:
  C-c C-d d    - Open Zig docs
  C-c C-d s    - Open std lib docs

LSP COMMANDS (via lsp-bridge with zls):
  M-.          - Go to definition
  M-,          - Return from definition
  M-?          - Find references
  C-c r r      - Rename symbol
  C-c r f      - Format buffer

═══════════════════════════════════════════

INSTALLATION:
  - Zig: https://ziglang.org/download/
  - ZLS: https://github.com/zigtools/zls

═══════════════════════════════════════════
")))

(provide 'init-zig)
;;; init-zig.el ends here
