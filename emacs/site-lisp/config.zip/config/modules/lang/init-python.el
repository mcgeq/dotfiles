;;; init-python.el --- Python language support for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: languages, python
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Python language support module for MCG Emacs:
;; - python-mode / python-ts-mode configuration
;; - pytest project and file commands
;; - Ruff check/fix/format helpers
;; - Python REPL entry point
;;

;;; Code:

(require 'core-lib)
(require 'cl-lib)
(require 'subr-x)
(require 'python)

;;; ============================================================
;;; Variables
;;; ============================================================

(defcustom mcg-python-test-command "python -m pytest"
  "Command used to run Python tests."
  :type 'string
  :group 'mcg)

(defcustom mcg-python-ruff-command "ruff"
  "Command used to run Ruff."
  :type 'string
  :group 'mcg)

(defcustom mcg-python-detect-project-tools t
  "Whether Python commands should prefer project-local tool runners.
When enabled, projects with uv, Poetry, or PDM lock files use the matching
runner when its executable is available."
  :type 'boolean
  :group 'mcg)

;;; ============================================================
;;; python-mode / python-ts-mode Configuration
;;; ============================================================

(defun mcg-python-mode-setup ()
  "Setup function for python-mode and python-ts-mode."
  (setq-local indent-tabs-mode nil)
  (setq-local tab-width 4)
  (setq-local python-indent-offset 4)
  (setq-local python-indent-guess-indent-offset nil)
  (subword-mode 1)
  (mcg-log "Python mode setup complete"))

(add-hook 'python-mode-hook #'mcg-python-mode-setup)
(add-hook 'python-ts-mode-hook #'mcg-python-mode-setup)

;;; ============================================================
;;; Helpers
;;; ============================================================

(defun mcg-python--project-root ()
  "Return the current Python project root or `default-directory'."
  (mcg-project-root-or-default))

(defun mcg-python--save-and-compile (command &optional root)
  "Save buffers and run COMMAND with `compile' in ROOT."
  (save-some-buffers t)
  (let ((default-directory (or root default-directory)))
    (compile command)))

(defun mcg-python--current-file ()
  "Return the current buffer file or raise a user error."
  (or buffer-file-name
      (user-error "Current buffer is not visiting a file")))

(defun mcg-python--quoted-current-file ()
  "Return the shell-quoted current buffer file."
  (shell-quote-argument (mcg-python--current-file)))

(defun mcg-python--project-file-p (root file)
  "Return non-nil when ROOT contains FILE."
  (file-exists-p (expand-file-name file root)))

(defun mcg-python--project-tool (&optional root)
  "Return the detected Python project tool for ROOT, or nil.
Only return a tool when `mcg-python-detect-project-tools' is enabled and the
corresponding executable is available."
  (let ((root (file-name-as-directory (or root (mcg-python--project-root)))))
    (when mcg-python-detect-project-tools
      (cond
       ((and (mcg-python--project-file-p root "uv.lock")
             (executable-find "uv"))
        "uv")
       ((and (mcg-python--project-file-p root "poetry.lock")
             (executable-find "poetry"))
        "poetry")
       ((and (mcg-python--project-file-p root "pdm.lock")
             (executable-find "pdm"))
        "pdm")))))

(defun mcg-python--project-tool-command (tool args &optional root)
  "Return project-aware command parts for TOOL with ARGS in ROOT."
  (pcase (mcg-python--project-tool root)
    ("uv" (append (list "uv" "run" tool) args))
    ("poetry" (append (list "poetry" "run" tool) args))
    ("pdm" (append (list "pdm" "run" tool) args))
    (_ (cons tool args))))

(defun mcg-python--command-string (parts)
  "Return shell command string from command PARTS."
  (string-join parts " "))

(defun mcg-python--pytest-command (&optional root)
  "Return the best pytest command for ROOT."
  (let ((tool (mcg-python--project-tool root)))
    (if tool
        (mcg-python--command-string
         (mcg-python--project-tool-command "pytest" nil root))
      mcg-python-test-command)))

(defun mcg-python-format-candidates (&optional root)
  "Return project-aware Python formatter command candidates for ROOT."
  (let* ((root (file-name-as-directory (or root (mcg-python--project-root))))
         (project-tool (mcg-python--project-tool root))
         (project-candidate
          (when project-tool
            (mcg-python--project-tool-command "ruff" '("format") root))))
    (append (when project-candidate (list project-candidate))
            (list (list mcg-python-ruff-command "format")
                  (list "black")))))

(defun mcg-python--ruff-command (&rest args)
  "Return the best Ruff command for ARGS, or raise a user error."
  (let ((candidate
         (cl-find-if (lambda (candidate)
                       (and (consp candidate)
                            (executable-find (car candidate))))
                     (let ((project-candidate
                            (mcg-python--project-tool-command "ruff" args)))
                       (append
                        (unless (equal (car project-candidate)
                                       mcg-python-ruff-command)
                          (list project-candidate))
                        (list (cons mcg-python-ruff-command args)))))))
    (unless candidate
      (user-error "No Ruff command found; install ruff or configure `mcg-python-ruff-command'"))
    (mcg-python--command-string candidate)))

;;; ============================================================
;;; Pytest Commands
;;; ============================================================

(defun mcg/python-pytest-project ()
  "Run pytest for the current project."
  (interactive)
  (mcg-python--save-and-compile (mcg-python--pytest-command)
                                (mcg-python--project-root)))

(defun mcg/python-pytest-file ()
  "Run pytest for the current Python file."
  (interactive)
  (mcg-python--save-and-compile
   (format "%s %s" (mcg-python--pytest-command)
           (mcg-python--quoted-current-file))
   (mcg-python--project-root)))

(defun mcg/python-pytest-test-at-point ()
  "Run pytest for the current test symbol when available."
  (interactive)
  (let ((test-name (which-function)))
    (if (and test-name (not (string-empty-p test-name)))
        (mcg-python--save-and-compile
         (format "%s %s::%s"
                 (mcg-python--pytest-command)
                 (mcg-python--quoted-current-file)
                 (shell-quote-argument test-name))
         (mcg-python--project-root))
      (mcg/python-pytest-file))))

;;; ============================================================
;;; Ruff Commands
;;; ============================================================

(defun mcg/python-ruff-check ()
  "Run Ruff check for the current project."
  (interactive)
  (mcg-python--save-and-compile
   (mcg-python--ruff-command "check" ".")
   (mcg-python--project-root)))

(defun mcg/python-ruff-fix ()
  "Run Ruff check --fix for the current project."
  (interactive)
  (mcg-python--save-and-compile
   (mcg-python--ruff-command "check" "--fix" ".")
   (mcg-python--project-root)))

(defun mcg/python-ruff-format ()
  "Run Ruff format for the current Python file."
  (interactive)
  (mcg-python--save-and-compile
   (format "%s %s"
           (mcg-python--ruff-command "format")
           (mcg-python--quoted-current-file))
   (mcg-python--project-root)))

;;; ============================================================
;;; REPL
;;; ============================================================

(defun mcg/python-repl ()
  "Open a Python REPL using built-in python.el."
  (interactive)
  (run-python (python-shell-calculate-command) nil nil))

;;; ============================================================
;;; Python Keybindings
;;; ============================================================

(defvar mcg-python-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c t") #'mcg/python-pytest-project)
    (define-key map (kbd "C-c C-c f") #'mcg/python-pytest-file)
    (define-key map (kbd "C-c C-c .") #'mcg/python-pytest-test-at-point)
    (define-key map (kbd "C-c C-c c") #'mcg/python-ruff-check)
    (define-key map (kbd "C-c C-c x") #'mcg/python-ruff-fix)
    (define-key map (kbd "C-c C-c F") #'mcg/python-ruff-format)
    (define-key map (kbd "C-c C-z") #'mcg/python-repl)
    map)
  "Keymap for Python-specific commands.")

(defun mcg-python-setup-keybindings ()
  "Setup Python-specific keybindings."
  (use-local-map (make-composed-keymap mcg-python-mode-map (current-local-map))))

(add-hook 'python-mode-hook #'mcg-python-setup-keybindings)
(add-hook 'python-ts-mode-hook #'mcg-python-setup-keybindings)

;;; ============================================================
;;; Help Command
;;; ============================================================

(defun mcg/python-help ()
  "Show Python keybindings and command help."
  (interactive)
  (with-help-window "*MCG Python Help*"
    (princ "
MCG Python Keybindings

TEST:
  C-c C-c t    - pytest project
  C-c C-c f    - pytest current file
  C-c C-c .    - pytest test at point

RUFF:
  C-c C-c c    - ruff check .
  C-c C-c x    - ruff check --fix .
  C-c C-c F    - ruff format current file

REPL:
  C-c C-z      - Python REPL

LSP COMMANDS (via lsp-bridge with ty/basedpyright + ruff):
  M-.          - Go to definition
  M-,          - Return from definition
  M-?          - Find references
  C-c r r      - Rename symbol
  C-c r f      - Format buffer
")))

(provide 'init-python)
;;; init-python.el ends here
