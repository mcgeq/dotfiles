;;; init-help.el --- Help and key discovery for MCG Emacs -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 MCG
;; Author: mcge <mcgeq@outlook.com>
;; Keywords: help, discoverability
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;; Configures built-in which-key and optional helpful.
;;
;;; Code:

(require 'core-lib)
(require 'which-key nil t)

(defcustom mcg-help-enable-which-key t
  "Whether to enable `which-key-mode'."
  :type 'boolean
  :group 'mcg)

(defcustom mcg-help-which-key-delay 0.4
  "Idle delay before showing which-key hints."
  :type 'number
  :group 'mcg)

(defun mcg-help--helpful-available-p ()
  "Return non-nil when helpful is available."
  (require 'helpful nil t))

(defun mcg-help-describe-function ()
  "Describe a function, using helpful when available."
  (interactive)
  (if (and (mcg-help--helpful-available-p)
           (fboundp 'helpful-callable))
      (call-interactively #'helpful-callable)
    (call-interactively #'describe-function)))

(defun mcg-help-describe-variable ()
  "Describe a variable, using helpful when available."
  (interactive)
  (if (and (mcg-help--helpful-available-p)
           (fboundp 'helpful-variable))
      (call-interactively #'helpful-variable)
    (call-interactively #'describe-variable)))

(defun mcg-help-describe-command ()
  "Describe an interactive command, using helpful when available."
  (interactive)
  (if (and (mcg-help--helpful-available-p)
           (fboundp 'helpful-command))
      (call-interactively #'helpful-command)
    (call-interactively #'describe-command)))

(defun mcg-help-describe-key ()
  "Describe a key, using helpful when available."
  (interactive)
  (if (and (mcg-help--helpful-available-p)
           (fboundp 'helpful-key))
      (call-interactively #'helpful-key)
    (call-interactively #'describe-key)))

(defun mcg-help-describe-symbol ()
  "Describe a symbol, using helpful when available."
  (interactive)
  (if (and (mcg-help--helpful-available-p)
           (fboundp 'helpful-symbol))
      (call-interactively #'helpful-symbol)
    (call-interactively #'describe-symbol)))

(defun mcg-help-describe-at-point ()
  "Describe the symbol at point, using helpful when available."
  (interactive)
  (if (and (mcg-help--helpful-available-p)
           (fboundp 'helpful-at-point))
      (call-interactively #'helpful-at-point)
    (let ((symbol (symbol-at-point)))
      (if symbol
          (describe-symbol symbol)
        (user-error "No symbol at point")))))

(when (and mcg-help-enable-which-key
           (featurep 'which-key))
  (setq which-key-idle-delay mcg-help-which-key-delay)
  (setq which-key-idle-secondary-delay 0.05)
  (setq which-key-show-early-on-C-h t)
  (setq which-key-sort-order 'which-key-key-order-alpha)
  (which-key-mode 1))

(define-prefix-command 'mcg-help-map)
(mcg-bind-key "C-c h" 'mcg-help-map "enhance/help")
(mcg-bind-key "C-c h f" #'mcg-help-describe-function "enhance/help")
(mcg-bind-key "C-c h v" #'mcg-help-describe-variable "enhance/help")
(mcg-bind-key "C-c h x" #'mcg-help-describe-command "enhance/help")
(mcg-bind-key "C-c h k" #'mcg-help-describe-key "enhance/help")
(mcg-bind-key "C-c h K" #'describe-keymap "enhance/help")
(mcg-bind-key "C-c h ." #'mcg-help-describe-at-point "enhance/help")
(mcg-bind-key "C-c h o" #'mcg-help-describe-symbol "enhance/help")
(mcg-bind-key "C-c h b" #'describe-bindings "enhance/help")
(mcg-bind-key "C-c h m" #'describe-mode "enhance/help")
(mcg-bind-key "C-c h w" #'where-is "enhance/help")
(mcg-bind-key "C-c h c" #'describe-char "enhance/help")
(mcg-bind-key "C-c h l" #'view-lossage "enhance/help")

(mcg-bind-key "C-h f" #'mcg-help-describe-function "enhance/help")
(mcg-bind-key "C-h v" #'mcg-help-describe-variable "enhance/help")
(mcg-bind-key "C-h k" #'mcg-help-describe-key "enhance/help")
(mcg-bind-key "C-h K" #'describe-keymap "enhance/help")
(mcg-bind-key "C-h ." #'mcg-help-describe-at-point "enhance/help")
(mcg-bind-key "C-h o" #'mcg-help-describe-symbol "enhance/help")

(define-key global-map [remap describe-command] #'mcg-help-describe-command)
(define-key global-map [remap describe-function] #'mcg-help-describe-function)
(define-key global-map [remap describe-variable] #'mcg-help-describe-variable)
(define-key global-map [remap describe-key] #'mcg-help-describe-key)
(define-key global-map [remap describe-symbol] #'mcg-help-describe-symbol)

(with-eval-after-load 'helpful
  (mcg-bind-key "C-c h F" #'helpful-function "enhance/help")
  (mcg-bind-key "C-h F" #'helpful-function "enhance/help")
  (define-key helpful-mode-map [remap revert-buffer] #'helpful-update)
  (define-key helpful-mode-map (kbd "C-x K") #'helpful-kill-buffers))

(mcg-log "help module configured")

(provide 'init-help)
;;; init-help.el ends here
