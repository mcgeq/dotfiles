;;; init-recentf.el --- Recentf Configuration for MCG Emacs -*- lexical-binding: t; -*-

;; Filename: init-recentf.el
;; Description: Recentf recent files module
;; Author: mcge <mcgeq@outlook.com>
;; Copyright (C) 2024-2026, mcge, all rights reserved.
;; Create   Date: 2026-01-10
;; Keywords: recentf, recent-files
;; Compatibility: GNU Emacs 29.0+

;;; Commentary:
;;
;; Recentf module for MCG Emacs, responsible for:
;; - Tracking recently opened files
;; - Configuring exclusion patterns
;;
;; Module metadata:
;; :depends ()
;; :defer nil
;;

;;; Code:

(require 'core-lib)

(unless mcg-cache-dir
  (mcg-init-paths))
(make-directory mcg-cache-dir t)
(setq recentf-save-file (expand-file-name "recentf.el" mcg-cache-dir))

(require 'recentf)

;;; ============================================================
;;; Recentf Configuration
;;; ============================================================

(defun mcg--setup-recentf ()
  "Setup Recentf recent files tracking."
  (unless mcg-cache-dir
    (mcg-init-paths))
  (make-directory mcg-cache-dir t)

  ;; Maximum number of saved items
  (setq recentf-max-saved-items 300)

  ;; Keep state files inside the MCG cache directory.
  (setq recentf-save-file (expand-file-name "recentf.el" mcg-cache-dir))
  
  ;; Don't auto-cleanup (can be slow)
  (setq recentf-auto-cleanup 'never)
  
  ;; Use abbreviated file names
  (setq recentf-filename-handlers '(abbreviate-file-name))
  
  ;; Exclude patterns - files/directories to ignore
  (setq recentf-exclude
        '(".cache"
          ".cask"
          ".elfeed"
          "bookmarks"
          "cache"
          "ido.*"
          "recentf"
          "undo-tree-hist"
          "url"
          "^/tmp/"
          "/ssh\\(x\\)?:"
          "/su\\(do\\)?:"
          "^/usr/include/"
          "/TAGS\\'"
          "COMMIT_EDITMSG\\'"
          ;; Emacs internal files
          "\\.elc\\'"
          "loaddefs\\.el\\'"
          ;; Package directories
          "/elpa/"
          "/straight/"
          ;; Temporary files
          "\\.tmp\\'"
          "\\.bak\\'"
          "~\\'"))
  
  ;; Enable recentf mode
  (recentf-mode 1)
  
  (mcg-log "Recentf configured (max items: %d)" recentf-max-saved-items))

;;; ============================================================
;;; Commands
;;; ============================================================

(defun mcg/recentf-open ()
  "Open a recent file using completing-read."
  (interactive)
  (let ((file (completing-read "Recent file: " recentf-list nil t)))
    (when file
      (find-file file))))

;;; ============================================================
;;; Initialize
;;; ============================================================

(mcg--setup-recentf)

(provide 'init-recentf)
;;; init-recentf.el ends here
